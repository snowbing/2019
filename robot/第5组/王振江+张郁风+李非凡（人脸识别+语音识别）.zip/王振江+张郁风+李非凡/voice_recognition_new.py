# -*- coding: utf-8 -*-
'''
关于python2的汉字字符问题，常用的解决方法：
tts中t2s函数，用.encode('utf-8')
汉字字符串前加u，
开头加上# -*- coding: utf-8 -*-
'''
import threading
import wave
import requests
import time
import base64
import json
from pyaudio import PyAudio, paInt16
import translate #翻译
import tts #读
import os
import chinese_idiom #成语
import weather #天气
import random
import search_song #找歌
import hotshot #新闻
import baike #百科
import sys
import rotate #小车动
import pygame #放mp3
import pyaudio #放wav
import client
import face_recognition
import face_dataset
import face_training
#import jieba #定闹钟
#import setclock
#import datetime
reload(sys)
sys.setdefaultencoding('utf-8')
#jieba.initialize()
#百度语音设置
framerate = 16000  # 采样率
num_samples = 2000  # 采样点
channels = 1  # 声道
sampwidth = 2  # 采样宽度2bytes
CHUNK = 1024
FILEPATH = '/home/pi/wangzhenjiang/wzj2/speech.wav'
KeyWord=u'你好'
base_url = "https://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=%s&client_secret=%s"
#api账号
item_dict={}
APP_ID = '16607316'
API_KEY = 'qAFLaQog5OL6sRG4pMt7ccL8'
SECRET_KEY = 'fnWHSORRQyZWdjRvGWlDcsoiAH6phqpc'
HOST = base_url % (API_KEY, SECRET_KEY)

#播放mp3
def play_mp3(music_file):
    pygame.mixer.init()
    pygame.mixer.music.load(music_file)
    pygame.mixer.music.play(loops=0)
    while True:
        if not pygame.mixer.music.get_busy():
            break
    pygame.mixer.music.stop()
#播放wav
def play(filename):
    os.system('aplay -D plughw:1,0 '+filename)
    
#多线程
def threadings(musicname):
    t2 = threading.Thread(target=play_mp3,args=(musicname,))
    t2.setDaemon(True)
    t2.start()
    stop_sing()

#等待唤醒
def confirm_record():#两种操作方式，一种是pyaudio，另一种是命令行。命令行控制更直接方便一点
    #pa = PyAudio()
    #stream = pa.open(format=paInt16, channels=channels,
    #                 rate=framerate, input=True, frames_per_buffer=num_samples)
    while True:
        os.system('arecord -D "plughw:0,0" -d 2 -r 16000 -f S16_LE /home/pi/wangzhenjiang/wzj2/speech.wav')#语音识别，注意plughw后面可能要修改
        #t=time.time()
        #my_buf=[]
        #while time.time()<t+2:
        #    string_audio_data=stream.read(num_samples)
        #    my_buf.append(string_audio_data)
        data = get_audio(FILEPATH)
        MyWord = speech2text(data, TOKEN, 1536)
        print(MyWord)
        if MyWord.find('小')>=0:
            print ("唤醒成功！")
            break
        else:
            print MyWord
    #stream.close()
#语音识别三函数
def getToken(host):
    res = requests.post(host,verify=False)
    return res.json()['access_token']
def get_audio(file):
    with open(file, 'rb') as f:
        data = f.read()
    return data
def speech2text(speech_data, token, dev_pid):
    FORMAT = 'wav'
    RATE = '16000'
    CHANNEL = 1
    CUID = '*******'
    SPEECH = base64.b64encode(speech_data).decode('utf-8')
    data = {
        'format': FORMAT,
        'rate': RATE,
        'channel': CHANNEL,
        'cuid': CUID,
        'len': len(speech_data),
        'speech': SPEECH,
        'token': token,
        'dev_pid': dev_pid
    }
    url = 'https://vop.baidu.com/server_api'
    headers = {'Content-Type': 'application/json'}
    # r=requests.post(url,data=json.dumps(data),headers=headers)
    print('正在识别...')
    r = requests.post(url, json=data, headers=headers)
    Result = r.json()
    if 'result' in Result:
        return str(Result['result'][0])
    else:
        return str(Result)
#多线程的函数，检测停是主线程，放歌是子线程。主线程识别到停后，强制子线程也停止。
#在电脑上能够正常运行，在树梅派上运行有些卡顿。
def stop_sing():
    print '开启关键字唤醒...' 
    while True:
        os.system('arecord -D "plughw:0,0" -d 2 -r 16000 -f S16_LE control.wav')
        data = get_audio('control.wav')
        MyWord = speech2text(data, TOKEN, 1536)
        print(MyWord)   
        if MyWord.find('停')>=0:
            print ("stop singing！")
            pygame.mixer.music.stop()
            break
        else:
            print MyWord
TOKEN=getToken(HOST)
def main():
    flag = 'yes'
    while flag.lower() == 'yes':
        TOKEN = getToken(HOST)
        confirm_record()
        print("识别成功，开始对话")
        tts.t2s("主人，来和我玩吧")
        while True:
            print 'function part'
            tts.t2s('叮')
            os.system('arecord -D "plughw:0,0" -d 4 -r 16000 -f S16_LE /home/pi/wangzhenjiang/wzj2/speech.wav') # 写录音
            command = get_audio(FILEPATH)  # 读录音
            result = speech2text(command, TOKEN, 1536)
            print(result)  # 获得录音的文字
            #关机
            if result.find('再见')>=0:
                tts.t2s("晚安，主人。")
                flag = 'yes'
                break
            #备忘录
            elif result.find('记事本')>=0 or result.find('备忘')>=0 or result.find('存')>=0:
                global item_dict
                tts.t2s('请说出您的东西在什么地方，让我记住')
                while True:
                    os.system('arecord -D "plughw:0,0" -d 8 -r 16000 -f S16_LE speech.wav')  # 写录音
                    item_speech = get_audio(FILEPATH)  # 读录音
                    item_text = speech2text(item_speech, TOKEN, 1536)
                    try:
                        item_dict[item_text.split('在')[0]] = item_text.split('在')[1]
                    except:
                        print 'error'
                    tts.t2s('还有吗')
                    os.system('arecord -D "plughw:0,0" -d 2 -r 16000 -f S16_LE speech.wav')  # 写录音
                    answer = get_audio(FILEPATH)  # 读录音,shuo jixu
                    answer= speech2text(answer, TOKEN, 1536)
                    if answer.find('没')>=0 or answer.find('不')>=0:
                        break
                    else:
                        tts.t2s("请说")
            #找东西
            elif result.find('找')>=0:
                print item_dict
                find=result.split('找')[1]
                if item_dict.get(find)==None:
                    tts.t2s('对不起，备忘录中没有这件物品。')
                else:
                    tts.t2s(find+'在'+item_dict.get(find))
            #小车
            elif result.find('车')>=0 or result.find('运动')>=0 or result.find('跑')>=0:
                tts.t2s('我是小车花花，我要开始动了，大家让开.')
                chip=rotate.STM()
                chip.TurnOn()
                while True:
                    tts.t2s('叮')
                    os.system('arecord -D "plughw:0,0" -d 3 -r 16000 -f S16_LE /home/pi/wangzhenjiang/wzj2/speech.wav')  # 写录音
                    command = get_audio(FILEPATH)  # 读录音
                    result = speech2text(command, TOKEN, 1536)
                    print result
                    if result.find('前')>=0 or result.find('进')>=0:
                        chip.Send('go$')
                    elif result.find('后')>=0 or result.find('退')>=0:
                        chip.Send('back$')
                    elif result.find('左')>=0:
                        chip.Send('left$')
                        chip.Send('left$')
                        chip.Send('stop$')
                    elif result.find('右')>=0:
                        chip.Send('right$')
                        chip.Send('right$')
                        chip.Send('stop$')
                    elif result.find('不')>=0:#
                        break
                    else:#停止
                        chip.Send('stop$')
            #新闻
            elif result.find('新闻')>=0:
                hotshot.main()
                tts.t2s("以下是最近的微博热搜")
                with open("hotshot.txt","r") as f:
                    news=f.readlines()
                    print(news)
                for item in news:
                    tts.t2s(item[0:-1])
            #英语翻译
            elif result.find('英语')>=0:
                translationflag=True
                while translationflag:
                    while True:
                        tts.t2s("我来翻译了，请说")
                        os.system('arecord -D "plughw:0,0" -d 10 -r 16000 -f S16_LE /home/pi/wangzhenjiang/wzj2/speech.wav')  # 写录音
                        speech1=get_audio(FILEPATH)
                        text1=speech2text(speech1,TOKEN,1536)
                        if len(text1)<2:
                            print("没听清")
                        elif text1.find("结束")>=0:
                            translationflag=False
                            break
                        else:
                            text2=translate.translate(text1)
                            tts.t2s(text2)
                            print(text2)#并读
            #百科
            elif result.find('百科')>=0:
                baikeflag=True
                while baikeflag:
                    stop=True
                    while stop:
                        tts.t2s("我是百科大全")
                        tts.t2s("请说出你想了解的事物")
                        os.system('arecord -D "plughw:0,0" -d 5 -r 16000 -f S16_LE /home/pi/wangzhenjiang/wzj2/speech.wav')  # 写录音
                        thing_speech = get_audio(FILEPATH)
                        thing_text = speech2text(thing_speech, TOKEN, 1536)
                        print thing_text
                        print type(thing_text)
                        print len(thing_text)
                        if thing_text.find("结束")>=0:
                            baikeflag=False
                            break
                        elif len(thing_text)<6 or len(thing_text)>18:#py2 one chinese character.len=3
                            tts.t2s("没听清，再来一次")
                            break
                        else:
                            description=baike.baike(thing_text)
                            tts.t2s(description)
                            print(description)  # 并读
                            #用pyaudio播放，系统等到运行结束才往下走，所以中间不需要sleep
            #本地找歌
            elif result.find("歌")>=0:
                singflag=True
                while singflag:
                    tts.t2s("你想听什么歌")
                    os.system('arecord -D "plughw:0,0" -d 5 -r 16000 -f S16_LE /home/pi/wangzhenjiang/wzj2/speech.wav')  # 写录音
                    songname_speech=get_audio(FILEPATH)
                    songname_text=str(speech2text(songname_speech,TOKEN,1536))
                    print(songname_text)
                    print len(songname_text)
                    print type(songname_text)
                    if songname_text=='':
                        continue
                    if songname_text.find("结束")>=0:
                        singflag=False
                        break
                    else:
                        fg=search_song.search_song('music',songname_text)
                        if fg==1:
                            print(songname_text)
                            tts.t2s("请慢慢欣赏")
                            pygame.mixer.init()
                            pygame.mixer.music.load('music/'+songname_text+'.mp3')
                            pygame.mixer.music.play()
                            time.sleep(20)
                            pygame.mixer.music.stop()
                            #threadings('music/'+songname_text+'.mp3')
                        else:
                            tts.t2s("对不起，没有这首歌")
            #天气预报
            elif result.find('天气')>=0:
                weatherflag=True
                while weatherflag:
                    stop=True
                    while stop:
                        tts.t2s("我来预报天气了")
                        tts.t2s("请说出城市名称")
                        os.system('arecord -D "plughw:0,0" -d 5 -r 16000 -f S16_LE /home/pi/wangzhenjiang/wzj2/speech.wav')  # 写录音
                        speech_city = get_audio(FILEPATH)
                        city = speech2text(speech_city, TOKEN, 1536)
                        print city
                        if city[-3:]=='市' or city[-3:]=='区' or city[-3:]=='县':
                            city=city[0:-3]
                        print city
                        if city.find("结束")>=0:
                            weatherflag=False
                            break
                        elif len(city)<6 or len(city)>18:
                            print("没听清，再来一次")
                            break
                        else:
                            weather_con=weather.get_weather(city)
                            tts.t2s(weather_con)
                            print(weather_con)  # 并读
                            #用pyaudio播放，系统等到运行结束才往下走，所以中间不需要sleep
            #成语解释
            elif result.find('成语')>=0:
                idiomflag=True
                while idiomflag:
                    tts.t2s("我来讲成语了，请说成语.")
                    os.system('arecord -D "plughw:0,0" -d 5 -r 16000 -f S16_LE /home/pi/wangzhenjiang/wzj2/speech.wav')  # 写录音
                    speech_idiom = get_audio(FILEPATH)
                    idiom = speech2text(speech_idiom, TOKEN, 1536)
                    if idiom.find("结束")>=0:
                        idiomflag=False
                        break
                    elif len(idiom)<3:
                        print("没听清，再来一次")
                        break
                    else:
                        explain = chinese_idiom.search(idiom)
                        tts.t2s(explain)
                        print(explain)  # 并读
            elif result.find('照相')>=0:
                tts.t2s("开始照相喽")
                client.test1()
            elif result.find('识别')>=0:
                tts.t2s("开始识别")
                face_recognition.face_recognition()
                tts.t2s('识别结束')
            elif result.find('学习')>=0:
                tts.t2s("开始照相")
                face_dataset.face_data()
                tts.t2s("结束照相")
                tts.t2s("开始学习")
                face_training.face_train()
                tts.t2s('学习结束')
            elif result.find('介绍')>=0:
                play('introduction.wav')
                #tts.t2s("Good morning！尊敬的老师们、创造我的以第五组帅哥们及看我表演的可爱的同学们！我叫小艾，我是你们的小可爱。因为我干活贼有劲，所以被主人安排上了，干起了责任重大的家庭助手工作。下面来说一下我的特长。第一个特长，我可以进行在家中扮演着保姆工作，给小孩子讲故事，放歌曲来哄他们。第二个特长，小艾可以智能地给主人提供消息便利，小艾可以预报天气，讲新闻给主人听，百度百科搜索，让主人远离手机危害就可以了解对应的消息。第三，小艾可以当主人的记忆盒子，主人放东西时和我说一声，下次想找东西时可以问我呀，嘻嘻，不错吧，小艾觉得很实用哦！下面说一下第三个特长，小艾可以学习和识别人脸，判断出这个人的特征。比如性别和年龄，小艾还会追踪人脸，去监督他们，尤其是家里的孩子，比如家里有个很淘气的小孩，不愿学习，只想玩，小艾可以帮助你监督他学习，他的一举一动你都可以用手机里的应用看得到！由于小艾可以追踪和识别人脸，当家里有陌生人进来时，小艾可以识别出，并呼叫主人。最后一个特长是，当家里有一些地方不方便人去观察时，小艾可以承担这部分工作，为主人探测事物！好了，居家小能手的小艾的自我介绍已经介绍完毕，超级具有魅力的老师们，如果对小艾好奇和有疑问，可以问问在台上答辩的帅哥们，祝老师们和同学们生活愉快，硬件综合训练分数举高高呢！")
                break
            #闹钟，在树梅派上分词过程过慢，取消此功能
            #elif result.find('闹钟'):
            #    tts.t2s('请您定闹钟吧')
            #    os.system('arecord -D "plughw:0,0" -d 8 -r 16000 -f S16_LE /home/pi/wangzhenjiang/wzj2/speech.wav')  # 写录音
            #    clock = get_audio(FILEPATH)
            #    clockword = speech2text(clock, TOKEN, 1536)
            #    global clocktime
            #    clocktime=setclock.Get_Time_Sign(clockword)
            #    tts.t2s('已为您设置'+clocktime+'的闹钟')
main()

