# -*- coding: utf-8 -*-
import urllib
import json
import sys
import tts
reload(sys)
sys.setdefaultencoding('utf-8')
'''
 #POST请求的目标URL
url="http://www.360chengyu.com/yixinyiyi.html"
headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.25 Safari/537.36 Core/1.70.3704.400 QQBrowser/10.4.3587.400"}
#打开Fddler请求窗口,点击WebForms选项查看数据体
request=urllib.request.Request(url,headers=headers)
response=urllib.request.urlopen(request)
print(response)
print(response.read().decode('utf-8'))
/html/body/div[1]/div[4]/div[2]/div/div/p[4]/text()
'''
from lxml import etree
import requests
import xpinyin
def search(idiom):
    pinyin=xpinyin.Pinyin().get_pinyin(idiom.decode('utf-8'), "")
    print pinyin
    url="http://www.360chengyu.com/"+pinyin+".html"
#你需要爬取的网页
    try:
        html=requests.get(url)
        html.encoding="utf-8"
        selecter=etree.HTML(html.text)
        #将你的xpath复制到三引号里面，因为xpath里可能有双引号，所以我们加上三引号比较靠谱
        s=selecter.xpath('/html/body/div[1]/div[4]/div[2]/div/div/p[4]/text()')[0]
        print(s)
        print(type(s[0]))
        return s.encode('utf-8')
    except:
        return '对不起，没有这个成语'.encode('utf-8')
        
#tts.t2s(search("七嘴八舌"))
