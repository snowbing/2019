# coding:utf-8
import serial
import sys
import RPi.GPIO as GPIO
import time
class STM(object):
	def __init__(self,port="/dev/ttyUSB0",baudrate=115200,timeout=0.5):
		self.port=port
		self.baudrate=baudrate
		self.timeout=timeout
		self.data=bytearray(33)
		self.ports=["/dev/ttyUSB0","/dev/ttyUSB0"]
		self.i=0
	def TurnOn(self):
		try:
			self.ser=serial.Serial(self.port,self.baudrate,timeout=self.timeout)
			if self.ser.isOpen():
				print "Gyroscope is opened"
				return True
			else:
				self.TurnOn()
		except:
			print "Serial open fail"
			time.sleep(0.5)
			if(self.i==0):
				self.i=1
			else:
				self.i=0
			self.port=self.ports[self.i]
			self.TurnOn()

	def Recive(self):
		while(True):
			try:
				print "Recive"
				self.ser.readinto(self.data)
				a=self.data.decode(encoding='utf-8')
				if ','in a:
						print a
						return a.encode('unicode-escape').decode('string_escape')
				else:
						pass
				self.data=bytearray(33)
			except:
				print "error"
				time.sleep(0.5)
				self.TurnOn()

	def Send(self,message):
		self.ser.write(message)
		self.ser.flushInput()
		# print "send successful"
		time.sleep(0.5)
		 
	def Reset(self):
		self.ser.write('slr90$')
		self.ser.write('sud90$')
		self.ser.flushInput()
		print "Reset successful"
		time.sleep(0.5)

#chip=STM()
#chip.TurnOn()
#chip.Send('sud0$')
