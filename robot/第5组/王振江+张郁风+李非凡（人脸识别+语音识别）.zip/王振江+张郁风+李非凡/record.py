# -*- coding: utf-8 -*-
import wave
import requests
import time
import base64
from pyaudio import PyAudio, paInt16
import sys
import os
reload(sys)
sys.setdefaultencoding('utf-8')
framerate = 16000  # 采样率
num_samples = 2000  # 采样点
channels = 1  # 声道
sampwidth = 2  # 采样宽度2bytes
FILEPATH = 'speech.wav'

base_url = "https://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=%s&client_secret=%s"
APP_ID = '16607316'
API_KEY = 'qAFLaQog5OL6sRG4pMt7ccL8'
SECRET_KEY = 'fnWHSORRQyZWdjRvGWlDcsoiAH6phqpc'

HOST = base_url % (API_KEY, SECRET_KEY)

def getToken(host):
    res = requests.post(host,verify=False)
    return res.json()['access_token']

def save_wave_file(filepath, data):
    wf = wave.open(filepath, 'wb')
    wf.setnchannels(channels)
    wf.setsampwidth(sampwidth)
    wf.setframerate(framerate)
    wf.writeframes(b''.join(data))
    wf.close()
def my_record(len):
    print('正在录音...')
    os.system('arecord -D "plughw:0,0" -d ' + str(len)  + ' -r 16000 -f S16_LE ' + FILEPATH)
    print('录音结束.')

def get_audio(file):
    with open(file, 'rb') as f:
        data = f.read()
    return data

def speech2text(speech_data, token, dev_pid):
    FORMAT = 'wav'
    RATE = '16000'
    CHANNEL = 1
    CUID = '*******'
    SPEECH = base64.b64encode(speech_data).decode('utf-8')

    data = {
        'format': FORMAT,
        'rate': RATE,
        'channel': CHANNEL,
        'cuid': CUID,
        'len': len(speech_data),
        'speech': SPEECH,
        'token': token,
        'dev_pid': dev_pid
    }
    url = 'https://vop.baidu.com/server_api'
    headers = {'Content-Type': 'application/json'}
    # r=requests.post(url,data=json.dumps(data),headers=headers)
    print('正在识别...')
    r = requests.post(url, json=data, headers=headers)
    Result = r.json()
    if 'result' in Result:
        return str(Result['result'][0])
    else:
        return str(Result)
#my_record(5)
#token=getToken(HOST)
#speech_data=get_audio(FILEPATH)
#print speech2text(speech_data, token, 1536)

