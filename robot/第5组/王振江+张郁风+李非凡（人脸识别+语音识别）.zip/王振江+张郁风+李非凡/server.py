#!/usr/bin/python
#coding=UTF-8
import commands
import socket
import rotate
import time

def start ():   #启动服务器 接受安卓设备发来的命令
    host = "192.168.137.207"
    port = 12345
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    i=-1
    data=[]
    global chip
    print "服务器就绪!"
    sud_angle = 0
    slr_angle = 90
    while True:
        i = i + 1
        print "等待接入..."
        conn,addr=s.accept()
        print'Connected by', addr
        data.append(conn.recv(1024))      #data用来储存传进来的命令
        print "Receive: "+data[i]
        conn.send("receive:"+data[i]+"\n")
        print data
        ##命令处理
        if data[i] == "Stop":
            chip.Send('stop$')
        if data[i] == "request":
            chip = rotate.STM()
            chip.TurnOn()
        if data[i] == "GoStraight":
            chip.Send('go$')
        if data[i] == "GoLeft":
            chip.Send('left$')
        if data[i] == "GoRight":
            chip.Send('right$')
        if data[i] == "GoBack":
            chip.Send('back$')
        if data[i] == "reset":
            chip.Send('sud0$')
            chip.Send('slr90$')
        if data[i] == "c_up":
            if (sud_angle+9)<=180 :
                sud_angle = sud_angle + 9
            chip.Send("sud" + str(sud_angle) + "$")
        if data[i] == "c_down":
            if (sud_angle-9)>=0 :
                sud_angle = sud_angle - 9
            chip.Send("sud" + str(sud_angle) + "$")
        if data[i] == "cw":
            if (slr_angle+9) <=180:
                slr_angle = slr_angle + 9
            chip.Send("slr"+ str(slr_angle)+"$")
        if data[i] == "anti_cw":
            if (slr_angle-9) >=0:
                slr_angle = slr_angle - 9
            chip.Send("slr"+ str(slr_angle)+"$")
        #语音识别接口
        if data[i] == "launch_voice":
            continue
        if data[i] == "shut_voice":
            continue
        #人脸识别接口
        if data[i] == "launch_face":
            continue
        if data[i] == "shut_face":
            continue
        if data[i] == "quit":
            s.close()
            conn.close()
            break

    conn.close()
if __name__ == '__main__':
    start();
