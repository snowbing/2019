# -*- coding: utf-8 -*-
import requests
import sys
import tts
reload(sys)
sys.setdefaultencoding('utf-8')
url='https://cdn.heweather.com/china-city-list.csv'
headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.25 Safari/537.36 Core/1.70.3704.400 QQBrowser/10.4.3587.400"}
strhtml=requests.get(url)
data=strhtml.text
data1=data.split("\n")
print(data)
print(1)
print(data1)
print(2)
for i in range(2):
    data1.remove(data1[0])

def get_weather(city):
    for item in data1:
        if city==item.split(',')[2]:
            str = item[0:11]
            url = "https://free-api.heweather.net/s6/weather/now?location=" + str + "&key=ce2161f224dc4a14901e0ef2e765bc2e"
            strhtml = requests.get(url, headers=headers)
            dict = strhtml.json()
            print(dict)
            str_date = "现在是" + dict[u'HeWeather6'][0][u'update']['loc'] + '。'  # riqi
            str_tmp = city+"市的气温为" + dict[u'HeWeather6'][0][u'now'][u'fl'] + '度。'
            str_weather = '天气状况为' + dict[u'HeWeather6'][0][u'now'][u'cond_txt'] + "," + "湿度" + dict[u'HeWeather6'][0][u'now'][u'hum'] + "%,"
            str_wind = dict[u'HeWeather6'][0][u'now'][u'wind_dir'] + dict[u'HeWeather6'][0][u'now'][u'wind_sc'] + '级。'
            print(type(dict[u'HeWeather6'][0][u'now'][u'cond_code']))
            print(dict[u'HeWeather6'][0][u'now'][u'cond_txt'])
            str_total = str_date + str_tmp + str_weather + str_wind
            print(str_total)
            return str_total.encode('utf-8')
            break
#a=get_weather('大连')
#tts.t2s(a.encode('utf-8'))

