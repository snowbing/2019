# -*- coding: utf-8 -*-
import os
import display
import sys
import time
import record 
reload(sys)
sys.setdefaultencoding('utf-8')
def search_song(dir,name):
    name=name.decode('utf-8')
    for file in os.listdir(dir):
        r = file.decode('utf-8')
        if name==r[0:-4]:
            print(r[0:-4])
            #display.play_mp3(dir+'/'+r)
            return 1
    return -1
            #display.play_mp3(dir+'/'+r)
#search_song('music','地球仪')

#display.play_mp3('music'+'/地球仪.mp3')
