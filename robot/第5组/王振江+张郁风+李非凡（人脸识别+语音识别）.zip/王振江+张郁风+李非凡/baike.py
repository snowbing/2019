# -*- coding: utf-8 -*-
import requests
from bs4 import BeautifulSoup
import sys
reload(sys)
import tts
sys.setdefaultencoding('utf-8')
headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36'}
def baike(thing):
    url='https://baike.baidu.com/item/'+thing
    html=requests.get(url,headers=headers)
    html.encoding="utf-8"
    #print(html.text)
    description=''
    try:
        soup = BeautifulSoup(html.text, "lxml")
        description=str(soup.find(attrs={"name":"description"})['content'])
        #print(type(description))
        return description
    except:
        print "没听清，再来一次"
'''
print(baike('李娜'))
print(baike('sad的无'))
tts.t2s(baike('韩馨蕴').encode('utf-8'))
'''
#print(baike('李娜'))
