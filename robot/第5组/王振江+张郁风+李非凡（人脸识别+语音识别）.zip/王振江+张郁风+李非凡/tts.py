# coding=utf-8
#文字转录音
#import tts，然后tts.s2t(文字）
import sys
import json
import os
import subprocess
import time
#import weather
import display
IS_PY3 = sys.version_info.major == 3
if IS_PY3:
    from urllib.request import urlopen
    from urllib.request import Request
    from urllib.error import URLError
    from urllib.parse import urlencode
    from urllib.parse import quote_plus
else:
    import urllib2
    from urllib import quote_plus
    from urllib2 import urlopen
    from urllib2 import Request
    from urllib2 import URLError
    from urllib import urlencode

API_KEY = '4E1BG9lTnlSeIf1NQFlrSq6h'
SECRET_KEY = '544ca4657ba8002e3dea3ac2f5fdd241'


# 发音人选择, 0为普通女声，1为普通男生，3为情感合成-度逍遥，4为情感合成-度丫丫，默认为普通女声
PER = 4
# 语速，取值0-15，默认为5中语速
SPD = 5
# 音调，取值0-15，默认为5中语调
PIT = 5
# 音量，取值0-9，默认为5中音量
VOL = 5
# 下载的文件格式, 3：mp3(default) 4： pcm-16k 5： pcm-8k 6. wav
AUE = 6

FORMATS = {3: "mp3", 4: "pcm", 5: "pcm", 6: "wav"}
FORMAT = FORMATS[AUE]

CUID = "123456PYTHON"

TTS_URL = 'http://tsn.baidu.com/text2audio'


class DemoError(Exception):
    pass


"""  TOKEN start """

TOKEN_URL = 'http://openapi.baidu.com/oauth/2.0/token'
SCOPE = 'audio_tts_post'  # 有此scope表示有tts能力，没有请在网页里勾选


def fetch_token():
    print("fetch token begin")
    params = {'grant_type': 'client_credentials',
              'client_id': API_KEY,
              'client_secret': SECRET_KEY}
    post_data = urlencode(params)
    if (IS_PY3):
        post_data = post_data.encode('utf-8')
    req = Request(TOKEN_URL, post_data)
    try:
        f = urlopen(req, timeout=5)
        result_str = f.read()
    except URLError as err:
        #print('token http response http code : ' + str(err.code))
        result_str = err.read()
    if (IS_PY3):
        result_str = result_str.decode()

    print(result_str)
    result = json.loads(result_str)
    print(result)
    if ('access_token' in result.keys() and 'scope' in result.keys()):
        if not SCOPE in result['scope'].split(' '):
            raise DemoError('scope is not correct')
        print('SUCCESS WITH TOKEN: %s ; EXPIRES IN SECONDS: %s' % (result['access_token'], result['expires_in']))
        return result['access_token']
    else:
        raise DemoError('MAYBE API_KEY or SECRET_KEY not correct: access_token or scope not found in token response')


"""  TOKEN end """

def t2s(TEXT):
    token = fetch_token()
    print(token)
    print(type(token))
    tex = quote_plus(TEXT)  # 此处TEXT需要两次urlencode
    print(tex)
    params = {'tok': token, 'tex': tex, 'per': PER, 'spd': SPD, 'pit': PIT, 'vol': VOL, 'aue': AUE, 'cuid': CUID,
              'lan': 'zh', 'ctp': 1}  # lan ctp 固定参数

    data = urlencode(params)
    print('test on Web Browser' + TTS_URL + '?' + data)

    req = Request(TTS_URL, data.encode('utf-8'))
    has_error = False
    try:
        print(1)
        f = urlopen(req)
        result_str = f.read()

        headers = dict((name.lower(), value) for name, value in f.headers.items())

        has_error = ('content-type' not in headers.keys() or headers['content-type'].find('audio/') < 0)
    except  URLError as err:
        print(2)
        #print('asr http response http code : ' + str(err.code))
        result_str = err.read()
        has_error = True

    save_file = "error.txt" if has_error else 'result.' + FORMAT
    with open(save_file, 'wb') as of:
        of.write(result_str)

    if has_error:
        if (IS_PY3):
            result_str = str(result_str, 'utf-8')
        print("tts api  error:" + result_str)

    print("result saved as :" + save_file)
    display.play(save_file)

#t2s("Good morning！尊敬的老师们、创造我的以第五组帅哥们及看我表演的可爱的同学们！我叫小艾，我是你们的小可爱。因为我干活贼有劲，所以被主人安排上了，干起了责任重大的家庭助手工作。下面来说一下我的特长。第一个特长，我可以进行在家中扮演着保姆工作，给小孩子讲故事，放歌曲来哄他们。第二个特长，小艾可以智能地给主人提供消息便利，小艾可以预报天气，讲新闻给主人听，百度百科搜索，让主人远离手机危害就可以了解对应的消息。第三，小艾可以当主人的记忆盒子，主人放东西时和我说一声，下次想找东西时可以问我呀，嘻嘻，不错吧，小艾觉得很实用哦！下面说一下第三个特长，小艾可以学习和识别人脸，判断出这个人的特征。比如性别和年龄，小艾还会追踪人脸，去监督他们，尤其是家里的孩子，比如家里有个很淘气的小孩，不愿学习，只想玩，小艾可以帮助你监督他学习，他的一举一动你都可以用手机里的应用看得到！由于小艾可以追踪和识别人脸，当家里有陌生人进来时，小艾可以识别出，并呼叫主人。最后一个特长是，当家里有一些地方不方便人去观察时，小艾可以承担这部分工作，为主人探测事物！好了，居家小能手的小艾的自我介绍已经介绍完毕，超级具有魅力的老师们，如果对小艾好奇和有疑问，可以问问在台上答辩的帅哥们，祝老师们和同学们生活愉快，硬件综合训练分数举高高呢！")
