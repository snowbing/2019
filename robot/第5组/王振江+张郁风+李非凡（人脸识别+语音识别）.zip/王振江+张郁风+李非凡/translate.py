# -*- coding: utf-8 -*-
# Date    : 2018-12-02 19:04:55
import wave
import requests
import time
import base64
import webbrowser
#import urllib.request
#import urllib.parse
import json
 #POST请求的目标URL
url="http://fanyi.youdao.com/translate?smartresult=dict&smartresult=rule"
headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.25 Safari/537.36 Core/1.70.3704.400 QQBrowser/10.4.3587.400"}
#打开Fddler请求窗口,点击WebForms选项查看数据体
'''
FormData={
'i': 'Sometimes your entire life boils down to one insane move.',
'from': 'AUTO',
'to': 'AUTO',
'smartresult': 'dict',
'client': 'fanyideskweb',
'salt': '15613586904155',
'sign': 'db44f1b79d3f743ee254b418b21a8c2d',
'ts': '1561358690415',
'bv': '05435bfabe443fca9224e64675e06aab',
'doctype': 'json',
'version': '2.1',
'keyfrom': 'fanyi.web',
'action': 'FY_BY_REALTlME'
}
'''
def translate(text):
    FormData = {
        'i': text,
        'from': 'AUTO',
        'to': 'AUTO',
        'smartresult': 'dict',
        'client': 'fanyideskweb',
        'salt': '15613586904155',
        'sign': 'db44f1b79d3f743ee254b418b21a8c2d',
        'ts': '1561358690415',
        'bv': '05435bfabe443fca9224e64675e06aab',
        'doctype': 'json',
        'version': '2.1',
        'keyfrom': 'fanyi.web',
        'action': 'FY_BY_REALTlME'
    }
    '''
    data=bytes(urllib.parse.urlencode(FormData).encode('utf-8'))
    request=urllib.request.Request(url,data=data,headers=headers)
    response=urllib.request.urlopen(request)
    #print(response.read().decode('utf-8'))
    result=json.loads(response.read().decode('utf-8'))
    print(result)
    afterTrans=result['translateResult']
    return afterTrans[0][0]['tgt']
    '''
    #use requests
    r=requests.post(url,headers=headers,data=FormData).json()
    print(r)
    print(type(r))
    afterTrans = r['translateResult']
    a=str(afterTrans[0][0]['tgt'])
    print(a)
    print(type(a))
    return a

#translate('今天太热了')
