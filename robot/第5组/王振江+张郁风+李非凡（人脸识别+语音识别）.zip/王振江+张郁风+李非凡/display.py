# -*- coding: utf-8 -*-
#from aip import AipSpeech  # 百度语音识别库
import pyaudio  # 麦克风声音采集库
import wave
import requests, json  # 音乐搜索
import pygame  # mp3播放
import os
import time
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
CHUNK = 1024
def play(filename):
    os.system('aplay -D plughw:1,0 result.wav')
    '''
    wf = wave.open(filename, 'rb')

    p = pyaudio.PyAudio()

    stream = p.open(format=p.get_format_from_width(wf.getsampwidth()),
                    channels=wf.getnchannels(),
                    rate=wf.getframerate(),
                    output=True)

    data = wf.readframes(CHUNK)

    while data != b'':
        stream.write(data)
        data = wf.readframes(CHUNK)

    stream.stop_stream()
    stream.close()

    p.terminate()
    '''
def play_mp3(music_file):
    pygame.mixer.init()
    pygame.mixer.music.load(music_file)
    pygame.mixer.music.play(loops=0)
    while 1:
        if not pygame.mixer.music.get_busy():
            break#歌曲结束后自动停止
#play('result.wav')
#play('result.wav')
