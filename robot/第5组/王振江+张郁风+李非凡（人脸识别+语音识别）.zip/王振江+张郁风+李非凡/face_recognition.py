# -*- coding: utf-8 -*-
import cv2
import numpy as np
import os 
import rotate
import socket
from PIL import Image
import StringIO
import time
import tts

def face_recognition():
    recognizer = cv2.createLBPHFaceRecognizer()
    recognizer.load('./trainer/trainer.yml')
    cascadePath = "./model/haarcascade_frontalface_default.xml"
    faceCascade = cv2.CascadeClassifier(cascadePath);

    font = cv2.FONT_HERSHEY_SIMPLEX

    #iniciate id counter
    id = 0

    # names related to ids: example ==> Marcelo: id=1,  etc
    names = ['陌生人', '李非凡','王振江','盛君如','张郁风','王泽浩'] 

    # Initialize and start realtime video capture
    cam = cv2.VideoCapture(0)
    cam.set(3, 320) # set video widht
    cam.set(4, 320) # set video height

    # Define min window size to be recognized as a face
    minW = 0.1*cam.get(3)
    minH = 0.1*cam.get(4)

    rot = rotate.STM()
    rot.TurnOn()
    rot.Send('sud0$')
    rot.Send('slr90$')
    now_lr = 90
    frame_count = 0

    ####
    HOST = "192.168.137.207"
    PORT = 12346    
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
    sock.bind((HOST, PORT))
    sock.listen(5)
    ####
    print"waiting..."
    dst, dst_addr = sock.accept()   
    print "conneted by",dst_addr


    def findface(x, now_lr):
        if(100 < x < 200):
            pass
        elif(x < 100):
            now_lr = now_lr - 9
            rot.Send('slr' + str(now_lr) + '$')
            if (now_lr < 0):
                now_lr = 0
        elif (x > 200):
            now_lr = now_lr + 9
            rot.Send('slr' + str(now_lr) + '$')
            if (now_lr > 180):
                now_lr = 180
    
        return now_lr
    
    while True:
        if (frame_count % 20 == 0):
            ret, img =cam.read()
            gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
            faces = faceCascade.detectMultiScale( 
                gray,
                scaleFactor = 1.2,
                minNeighbors = 5,
                minSize = (int(minW), int(minH)),
            )

            for(x,y,w,h) in faces:
        
                cv2.rectangle(img, (x,y), (x+w,y+h), (0,255,0), 2)
                #print 'x:',x,'y:',y
                #print 'weizhi:',now_lr
        
                now_lr = findface(x+(w/2), now_lr)

                id, confidence = recognizer.predict(gray[y:y+h,x:x+w])

                # Check if confidence is less them 100 ==> "0" is perfect match 
                if (confidence < 100):
                    id = names[id]
                    # confidence = "  {0}%".format(round(100 - confidence))
                    tts.t2s("你好" + id)
                else:
                    id = "陌生人"
                    # confidence = "  {0}%".format(round(100 - confidence))
                    tts.t2s("你好" + id)
                
                #cv2.putText(img, str(id), (x+5,y-5), font, 1, (255,255,255), 2)
                #cv2.putText(img, str(confidence), (x+5,y+h-5), font, 1, (255,255,0), 1)  
    
            #cv2.imshow('camera',img)
        
            ##########
            pi = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
            buf = StringIO.StringIO()  
            pi.save(buf, format='JPEG')  
            jpeg = buf.getvalue()  
            size = buf.len
            print "Size:",size
            buf.close()
            str_size = str(size)
            dst.send(str_size+"\n"+"null")
            print str_size
            ok = dst.recv(2)
            if ok == "qq":
                sock.close()
                break
            print ok
            dst.sendall(jpeg) 
            print"wait receive"
            fresh = dst.recv(5)
            print fresh
            #########
        
            k = cv2.waitKey(10) & 0xff # Press 'ESC' for exiting video
            if k == 27:
                break
        else:
            frame_count = frame_count + 1

    # Do a bit of cleanup
    print("\n [INFO] Exiting Program and cleanup stuff")
    cam.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    face_recognition()
