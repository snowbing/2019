# -*- coding: utf-8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import xpinyin
from pypinyin import pinyin, lazy_pinyin, Style, load_phrases_dict, load_single_dict
from pypinyin.style import register
def pinyin(str):
    pinyin=''
    pinyin_list=lazy_pinyin(str)
    for item in pinyin_list:
        item=item.encode('utf-8')
        print 1
        print type(item)
        print(item[2:-1])
        print 2
        pinyin=pinyin+item[2:-1]
    print (pinyin)

pinyin(u'你好')
