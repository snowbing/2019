# coding:utf-8
import socket
import cv2 as cv
import numpy
import tts

def get_host_ip():
	try:
		s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		s.connect(('8.8.8.8', 8002))
		ip = s.getsockname()[0]
	finally:
		s.close()
	return ip
def test1():
    address = ('192.168.137.233', 8002)
    #piaddress =('172.20.10.12',8002)
    sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sock.connect(address)

    capture = cv.VideoCapture(0)
    ret, frame = capture.read()
    encode_param=[int(cv.IMWRITE_JPEG_QUALITY),90]

    num=0

    while ret:
        result, imgencode = cv.imencode('.jpg', frame, encode_param)
        data = numpy.array(imgencode)
        stringData = data.tostring()
        sock.send( str(len(stringData)).ljust(16));
        sock.send( stringData );
        ret, frame = capture.read()
        #cv2.imshow('CLIENT',decimg)
        num +=1
        if num >20:
            break
            
    recivedata=sock.recv(1024)
    a=recivedata.decode('utf-8')
    print a
    print type(a)
    #tts.t2s(a)
    tts.t2s(a.encode('utf-8'))
    sock.close()

#test1()
