// Zen_FanDlg.h : header file
//

#if !defined(AFX_ZEN_FANDLG_H__B66372BD_7B45_4494_BC80_3C99B5AF9608__INCLUDED_)
#define AFX_ZEN_FANDLG_H__B66372BD_7B45_4494_BC80_3C99B5AF9608__INCLUDED_

#include "OpenGLView.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CZen_FanDlg dialog

class CZen_FanDlg : public CDialog
{
// Construction
public:
	int Flag[9];
	int JudgeAnswer(double vnx, double vny, double vnz, double vox, double voy, double voz,double vax,double vay,double vaz,double vpx, double vpy, double vpz);
	CString DetAngScal(double aa,double bb,double cc,double dd,double ee);
	~CZen_FanDlg();
	COpenGLView *m_pDisplay;
	void RunNijie();
	void RunZheng();
	CZen_FanDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CZen_FanDlg)
	enum { IDD = IDD_ZEN_FAN_DIALOG };
	double	m_ax;
	double	m_ay;
	double	m_az;
	double	m_nx;
	double	m_ny;
	double	m_nz;
	double	m_ino1;
	double	m_ino2;
	double	m_ino3;
	double	m_ino4;
	double	m_ino5;
	double	m_ino6;
	double	m_ox;
	double	m_oy;
	double	m_oz;
	double	m_px;
	double	m_py;
	double	m_pz;
	double	m_OutO11;
	double	m_OutO12;
	double	m_OutO13;
	double	m_OutO14;
	double	m_OutO15;
	double	m_OutO16;
	double	m_OutO21;
	double	m_OutO23;
	double	m_OutO22;
	double	m_OutO24;
	double	m_OutO25;
	double	m_OutO26;
	double	m_OutO31;
	double	m_OutO32;
	double	m_OutO33;
	double	m_OutO34;
	double	m_OutO35;
	double	m_OutO36;
	double	m_OutO41;
	double	m_OutO42;
	double	m_OutO43;
	double	m_OutO44;
	double	m_OutO45;
	double	m_OutO46;
	double	m_OutO51;
	double	m_OutO52;
	double	m_OutO53;
	double	m_OutO54;
	double	m_OutO55;
	double	m_OutO56;
	double	m_OutO61;
	double	m_OutO62;
	double	m_OutO63;
	double	m_OutO64;
	double	m_OutO65;
	double	m_OutO66;
	double	m_OutO71;
	double	m_OutO72;
	double	m_OutO73;
	double	m_OutO74;
	double	m_OutO75;
	double	m_OutO76;
	double	m_OutO81;
	double	m_OutO82;
	double	m_OutO83;
	double	m_OutO84;
	double	m_OutO85;
	double	m_OutO86;
	CString	m_explain2;
	CString	m_explain4;
	CString	m_explain6;
	CString	m_explain8;
	CString	m_explain1;
	CString	m_explain3;
	CString	m_explain5;
	CString	m_explain7;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CZen_FanDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CZen_FanDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnRunZhengJie();
	afx_msg void OnRunNi();
	afx_msg void OnDisAns1();
	afx_msg void OnDisAns2();
	afx_msg void OnDisAns3();
	afx_msg void OnDisAns4();
	afx_msg void OnDisAns5();
	afx_msg void OnDisAns6();
	afx_msg void OnDisAns7();
	afx_msg void OnDisAns8();
	afx_msg void OnCalLinePos();
	afx_msg void OnCalLinePosNei();
	afx_msg void OnDisScaleOut();
	afx_msg void OnDrawOut();
	afx_msg void OnDrawIn();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ZEN_FANDLG_H__B66372BD_7B45_4494_BC80_3C99B5AF9608__INCLUDED_)
