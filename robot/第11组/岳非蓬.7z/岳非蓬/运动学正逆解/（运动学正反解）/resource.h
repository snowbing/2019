//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Zen_Fan.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ZEN_FAN_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_InO1                        1000
#define IDC_NX                          1001
#define IDC_RunZhengJie                 1002
#define IDC_InO2                        1003
#define IDC_InO3                        1004
#define IDC_InO4                        1005
#define IDC_InO5                        1006
#define IDC_InO6                        1007
#define IDC_DisAns1                     1008
#define IDC_DisAns2                     1009
#define IDC_DisAns3                     1010
#define IDC_NY                          1011
#define IDC_NZ                          1012
#define IDC_OX                          1013
#define IDC_OY                          1014
#define IDC_OZ                          1015
#define IDC_AX                          1016
#define IDC_AY                          1017
#define IDC_AZ                          1018
#define IDC_PX                          1019
#define IDC_PY                          1020
#define IDC_PZ                          1021
#define IDC_OutO11                      1022
#define IDC_OutO12                      1023
#define IDC_OutO13                      1024
#define IDC_OutO14                      1025
#define IDC_OutO15                      1026
#define IDC_OutO16                      1027
#define IDC_RunNi                       1028
#define IDC_OutO21                      1029
#define IDC_OutO22                      1030
#define IDC_OutO23                      1031
#define IDC_OutO24                      1032
#define IDC_OutO25                      1033
#define IDC_OutO26                      1034
#define IDC_DisAns4                     1035
#define IDC_DisAns5                     1036
#define IDC_DisAns6                     1037
#define IDC_DisAns7                     1038
#define IDC_DisAns8                     1039
#define IDC_Explain2                    1040
#define IDC_Explain4                    1041
#define IDC_Explain6                    1042
#define IDC_Explain8                    1043
#define IDC_Explain1                    1044
#define IDC_Explain3                    1045
#define IDC_Explain5                    1046
#define IDC_Explain7                    1047
#define IDC_CalLinePos                  1048
#define IDC_CalLinePosNei               1049
#define IDC_DrawPoint                   1050
#define IDC_DisScaleOut                 1051
#define IDC_DrawOut                     1052
#define IDC_DrawIn                      1053
#define IDC_OutO31                      1071
#define IDC_OutO32                      1072
#define IDC_OutO33                      1073
#define IDC_OutO34                      1074
#define IDC_OutO35                      1075
#define IDC_OutO36                      1076
#define IDC_OutO41                      1077
#define IDC_OutO42                      1078
#define IDC_OutO43                      1079
#define IDC_OutO44                      1080
#define IDC_OutO45                      1081
#define IDC_OutO46                      1082
#define IDC_OutO51                      1083
#define IDC_OutO52                      1084
#define IDC_OutO53                      1085
#define IDC_OutO54                      1086
#define IDC_OutO55                      1087
#define IDC_OutO56                      1088
#define IDC_OutO61                      1089
#define IDC_OutO62                      1090
#define IDC_OutO63                      1091
#define IDC_OutO64                      1092
#define IDC_OutO65                      1093
#define IDC_OutO66                      1094
#define IDC_OutO71                      1095
#define IDC_OutO72                      1096
#define IDC_OutO73                      1097
#define IDC_OutO74                      1098
#define IDC_OutO75                      1099
#define IDC_OutO76                      1100
#define IDC_OutO81                      1101
#define IDC_OutO82                      1102
#define IDC_OutO83                      1103
#define IDC_OutO84                      1104
#define IDC_OutO85                      1105
#define IDC_OutO86                      1106

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1053
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
