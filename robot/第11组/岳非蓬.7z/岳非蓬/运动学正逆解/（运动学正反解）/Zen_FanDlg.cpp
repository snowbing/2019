// Zen_FanDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Zen_Fan.h"
#include "Zen_FanDlg.h"
#include "math.h"

#include <iostream.h>
#include <fstream.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define  PI 3.1415926535897932384626433 
#define L1 150
#define L2 614
#define L3 155
#define L4 -640
#define L6 0




//////////////////////////////////////////////////////////
//define variable
//////////////////////////////////////////////////////////

double ino[7];//����ĽǶ�ֵ
double nx,ny,nz,ox,oy,oz,ax,ay,az,px,py,pz;//ת�������ֵ
double outo[9][7];//����Ƕ�ֵ
int pointnum;//��¼�ǵڼ��е�����
int DrawFlag[2];//�ж��Ƿ�Ҫ��ʾ��ά�ռ����ά�ռ������
int ranum[9];//��¼��ȷ������ĸ���
int flagg[9];//���ݱ�־λֵ

extern float CS_Left[6];
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CZen_FanDlg dialog

CZen_FanDlg::CZen_FanDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CZen_FanDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CZen_FanDlg)
	m_ax = 0.0;
	m_ay = 0.0;
	m_az = 0.0;
	m_nx = 0.0;
	m_ny = 0.0;
	m_nz = 0.0;
	m_ino1 = 0.0;
	m_ino2 = 0.0;
	m_ino3 = 0.0;
	m_ino4 = 0.0;
	m_ino5 = 0.0;
	m_ino6 = 0.0;
	m_ox = 0.0;
	m_oy = 0.0;
	m_oz = 0.0;
	m_px = 0.0;
	m_py = 0.0;
	m_pz = 0.0;
	m_OutO11 = 10.01;
	m_OutO12 = 10.01;
	m_OutO13 = 10.01;
	m_OutO14 = 10.01;
	m_OutO15 = 10.01;
	m_OutO16 = 10.01;
	m_OutO21 = 10.01;
	m_OutO23 = 10.01;
	m_OutO22 = 10.01;
	m_OutO24 = 10.01;
	m_OutO25 = 10.01;
	m_OutO26 = 10.01;
	m_OutO31 = 10.01;
	m_OutO32 = 10.01;
	m_OutO33 = 10.01;
	m_OutO34 = 10.01;
	m_OutO35 = 10.01;
	m_OutO36 = 10.01;
	m_OutO41 = 10.01;
	m_OutO42 = 10.01;
	m_OutO43 = 10.01;
	m_OutO44 = 10.01;
	m_OutO45 = 10.01;
	m_OutO46 = 10.01;
	m_OutO51 = 10.01;
	m_OutO52 = 10.01;
	m_OutO53 = 10.01;
	m_OutO54 = 10.01;
	m_OutO55 = 10.01;
	m_OutO56 = 10.01;
	m_OutO61 = 10.01;
	m_OutO62 = 10.01;
	m_OutO63 = 10.01;
	m_OutO64 = 10.01;
	m_OutO65 = 10.01;
	m_OutO66 = 10.01;
	m_OutO71 = 10.01;
	m_OutO72 = 10.01;
	m_OutO73 = 10.01;
	m_OutO74 = 10.01;
	m_OutO75 = 10.01;
	m_OutO76 = 10.01;
	m_OutO81 = 10.01;
	m_OutO82 = 10.01;
	m_OutO83 = 10.01;
	m_OutO84 = 10.01;
	m_OutO85 = 10.01;
	m_OutO86 = 10.01;
	m_explain2 = _T("");
	m_explain4 = _T("");
	m_explain6 = _T("");
	m_explain8 = _T("");
	m_explain1 = _T("");
	m_explain3 = _T("");
	m_explain5 = _T("");
	m_explain7 = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pDisplay=new COpenGLView;
	pointnum=0;
	for (int i=1;i<9;i++)
	{
		Flag[i]=1;
		ranum[i]=0;
	}
	DrawFlag[0]=0;
	DrawFlag[1]=0;
}

void CZen_FanDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CZen_FanDlg)
	DDX_Text(pDX, IDC_AX, m_ax);
	DDX_Text(pDX, IDC_AY, m_ay);
	DDX_Text(pDX, IDC_AZ, m_az);
	DDX_Text(pDX, IDC_NX, m_nx);
	DDX_Text(pDX, IDC_NY, m_ny);
	DDX_Text(pDX, IDC_NZ, m_nz);
	DDX_Text(pDX, IDC_InO1, m_ino1);
	DDX_Text(pDX, IDC_InO2, m_ino2);
	DDX_Text(pDX, IDC_InO3, m_ino3);
	DDX_Text(pDX, IDC_InO4, m_ino4);
	DDX_Text(pDX, IDC_InO5, m_ino5);
	DDX_Text(pDX, IDC_InO6, m_ino6);
	DDX_Text(pDX, IDC_OX, m_ox);
	DDX_Text(pDX, IDC_OY, m_oy);
	DDX_Text(pDX, IDC_OZ, m_oz);
	DDX_Text(pDX, IDC_PX, m_px);
	DDX_Text(pDX, IDC_PY, m_py);
	DDX_Text(pDX, IDC_PZ, m_pz);
	DDX_Text(pDX, IDC_OutO11, m_OutO11);
	DDX_Text(pDX, IDC_OutO12, m_OutO12);
	DDX_Text(pDX, IDC_OutO13, m_OutO13);
	DDX_Text(pDX, IDC_OutO14, m_OutO14);
	DDX_Text(pDX, IDC_OutO15, m_OutO15);
	DDX_Text(pDX, IDC_OutO16, m_OutO16);
	DDX_Text(pDX, IDC_OutO21, m_OutO21);
	DDX_Text(pDX, IDC_OutO23, m_OutO23);
	DDX_Text(pDX, IDC_OutO22, m_OutO22);
	DDX_Text(pDX, IDC_OutO24, m_OutO24);
	DDX_Text(pDX, IDC_OutO25, m_OutO25);
	DDX_Text(pDX, IDC_OutO26, m_OutO26);
	DDX_Text(pDX, IDC_OutO31, m_OutO31);
	DDX_Text(pDX, IDC_OutO32, m_OutO32);
	DDX_Text(pDX, IDC_OutO33, m_OutO33);
	DDX_Text(pDX, IDC_OutO34, m_OutO34);
	DDX_Text(pDX, IDC_OutO35, m_OutO35);
	DDX_Text(pDX, IDC_OutO36, m_OutO36);
	DDX_Text(pDX, IDC_OutO41, m_OutO41);
	DDX_Text(pDX, IDC_OutO42, m_OutO42);
	DDX_Text(pDX, IDC_OutO43, m_OutO43);
	DDX_Text(pDX, IDC_OutO44, m_OutO44);
	DDX_Text(pDX, IDC_OutO45, m_OutO45);
	DDX_Text(pDX, IDC_OutO46, m_OutO46);
	DDX_Text(pDX, IDC_OutO51, m_OutO51);
	DDX_Text(pDX, IDC_OutO52, m_OutO52);
	DDX_Text(pDX, IDC_OutO53, m_OutO53);
	DDX_Text(pDX, IDC_OutO54, m_OutO54);
	DDX_Text(pDX, IDC_OutO55, m_OutO55);
	DDX_Text(pDX, IDC_OutO56, m_OutO56);
	DDX_Text(pDX, IDC_OutO61, m_OutO61);
	DDX_Text(pDX, IDC_OutO62, m_OutO62);
	DDX_Text(pDX, IDC_OutO63, m_OutO63);
	DDX_Text(pDX, IDC_OutO64, m_OutO64);
	DDX_Text(pDX, IDC_OutO65, m_OutO65);
	DDX_Text(pDX, IDC_OutO66, m_OutO66);
	DDX_Text(pDX, IDC_OutO71, m_OutO71);
	DDX_Text(pDX, IDC_OutO72, m_OutO72);
	DDX_Text(pDX, IDC_OutO73, m_OutO73);
	DDX_Text(pDX, IDC_OutO74, m_OutO74);
	DDX_Text(pDX, IDC_OutO75, m_OutO75);
	DDX_Text(pDX, IDC_OutO76, m_OutO76);
	DDX_Text(pDX, IDC_OutO81, m_OutO81);
	DDX_Text(pDX, IDC_OutO82, m_OutO82);
	DDX_Text(pDX, IDC_OutO83, m_OutO83);
	DDX_Text(pDX, IDC_OutO84, m_OutO84);
	DDX_Text(pDX, IDC_OutO85, m_OutO85);
	DDX_Text(pDX, IDC_OutO86, m_OutO86);
	DDX_Text(pDX, IDC_Explain2, m_explain2);
	DDX_Text(pDX, IDC_Explain4, m_explain4);
	DDX_Text(pDX, IDC_Explain6, m_explain6);
	DDX_Text(pDX, IDC_Explain8, m_explain8);
	DDX_Text(pDX, IDC_Explain1, m_explain1);
	DDX_Text(pDX, IDC_Explain3, m_explain3);
	DDX_Text(pDX, IDC_Explain5, m_explain5);
	DDX_Text(pDX, IDC_Explain7, m_explain7);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CZen_FanDlg, CDialog)
	//{{AFX_MSG_MAP(CZen_FanDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_RunZhengJie, OnRunZhengJie)
	ON_BN_CLICKED(IDC_RunNi, OnRunNi)
	ON_BN_CLICKED(IDC_DisAns1, OnDisAns1)
	ON_BN_CLICKED(IDC_DisAns2, OnDisAns2)
	ON_BN_CLICKED(IDC_DisAns3, OnDisAns3)
	ON_BN_CLICKED(IDC_DisAns4, OnDisAns4)
	ON_BN_CLICKED(IDC_DisAns5, OnDisAns5)
	ON_BN_CLICKED(IDC_DisAns6, OnDisAns6)
	ON_BN_CLICKED(IDC_DisAns7, OnDisAns7)
	ON_BN_CLICKED(IDC_DisAns8, OnDisAns8)
	ON_BN_CLICKED(IDC_CalLinePos, OnCalLinePos)
	ON_BN_CLICKED(IDC_CalLinePosNei, OnCalLinePosNei)
	ON_BN_CLICKED(IDC_DisScaleOut, OnDisScaleOut)
	ON_BN_CLICKED(IDC_DrawOut, OnDrawOut)
	ON_BN_CLICKED(IDC_DrawIn, OnDrawIn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CZen_FanDlg message handlers

BOOL CZen_FanDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	CRect rect(500,3,950,330);

	m_pDisplay->Create(NULL,NULL,WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_VISIBLE,rect,this,0);



	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CZen_FanDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CZen_FanDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CZen_FanDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CZen_FanDlg::RunZheng()
{
	double s1,s2,s3,s4,s5,s6,c1,c2,c3,c4,c5,c6,s23,c23;//�����s23Ϊsin(o2-o3),c23Ϊcos(o2-o3)
	

		
	s1=sin(ino[1]);
	s2=sin(ino[2]);
	s3=sin(ino[3]);
	s4=sin(ino[4]);
	s5=sin(ino[5]);
	s6=sin(ino[6]);

	c1=cos(ino[1]);
	c2=cos(ino[2]);
	c3=cos(ino[3]);
	c4=cos(ino[4]);
	c5=cos(ino[5]);
	c6=cos(ino[6]);

	s23=s2*c3-s3*c2;
	c23=c2*c3+s2*s3;

	
////////////////��ת���������Ԫ�ص�ֵ

	nx = -1*s1*(s4*c5*c6+c4*s6) + c1*c23*c4*c5*c6 + c1*s23*s5*c6 - c1*c23*s4*s6;
	if (nx<0.0000000001&&nx>-0.0000000001)
	{nx=0;
	}

	
	ny = c1*(s4*c5*c6+c4*s6) + s1*c23*c4*c5*c6 + s1*s23*s5*c6 - s1*c23*s4*s6;
	if (ny<0.0000000001&&ny>-0.0000000001)
	{ny=0;
	}

	nz = -1*s23*c4*c5*c6 + c23*s5*c6 + s23*s4*s6;
	if (nz<0.0000000001&&nz>-0.0000000001)
	{nz=0;
	}




	ox = -1*s1*(s4*c5*s6-c4*c6) + c1*c23*c4*c5*s6 + c1*s23*s5*s6 + c1*c23*s4*c6;
	if (ox<0.0000000001&&ox>-0.0000000001)
	{ox=0;
	}

	oy = c1*(s4*c5*s6-c4*c6) + s1*c23*c4*c5*s6 + s1*s23*s5*s6 + s1*c23*s4*c6;
	if (oy<0.0000000001&&oy>-0.0000000001)
	{oy=0;
	}

	oz = -1*s23*c4*c5*s6 + c23*s5*s6 - s23*s4*c6;
	if (oz<0.0000000001&&oz>-0.0000000001)
	{oz=0;
	}

	ax = c1*c23*c4*s5 - c1*s23*c5 - s1*s4*s5;
	if (ax<0.0000000001&&ax>-0.0000000001)
	{ax=0;
	}

	ay = s1*c23*c4*s5 - s1*s23*c5 + c1*s4*s5;
	if (ay<0.0000000001&&ay>-0.0000000001)
	{ay=0;
	}

	az = -1*s23*c4*s5 - c23*c5;
	if (az<0.0000000001&&az>-0.0000000001)
	{az=0;
	}

	px = -1*L6*c1*c23*c4*s5 + L6*s1*s4*s5 + L6*c1*s23*c5 + L4*c1*s23 + L3*c1*c23 + L2*c1*c2 + L1*c1;
	if (px<0.0000000001&&px>-0.0000000001)
	{px=0;
	}

	py = -1*L6*s1*c23*c4*s5 - L6*c1*s4*s5 + L6*s1*s23*c5 + L4*s1*s23 + L3*s1*c23 + L2*s1*c2 + L1*s1;
	if (py<0.0000000001&&py>-0.0000000001)
	{py=0;
	}

	pz = L6*s23*c4*s5 + L6*c23*c5 + L4*c23 - L3*s23 - L2*s2;
	if (pz<0.0000000001&&pz>-0.0000000001)
	{pz=0;
	}

}

void CZen_FanDlg::RunNijie()//�����
{
	double s1[3],s2[5],s3[5],s4[9],s5[9],c1[3],c2[5],c3[5],c4[9],c5[9],s23[5],c23[5];//�����s23Ϊsin(o2-o3),c23Ϊcos(o2-o3)
	double u[3],v,a[3],h[5],w[3];//�м������ʡ��д�ܳ���ʽ��

//��o1,��������
	outo[1][1]=atan2(ay*L6+py,ax*L6+px);
	c1[1]=cos(outo[1][1]);
	s1[1]=sin(outo[1][1]);

	outo[3][1]=outo[1][1];
	outo[5][1]=outo[1][1];
	outo[7][1]=outo[1][1];

	outo[2][1]=atan2(-ay*L6-py,-ax*L6-px);
	c1[2]=cos(outo[2][1]);
	s1[2]=sin(outo[2][1]);

	outo[4][1]=outo[2][1];
	outo[6][1]=outo[2][1];
	outo[8][1]=outo[2][1];
	
//��o2������o1�������⣬o2���ĸ���,
	u[1] = c1[1]*(ax*L6+px) + s1[1]*(ay*L6+py) - L1;
	v = az*L6 + pz;
	a[1] = (L3*L3+L4*L4-L2*L2-u[1]*u[1]-v*v)/(2*L2);

	u[2] = c1[2]*(ax*L6+px) + s1[2]*(ay*L6+py) - L1;
	a[2] = (L3*L3+L4*L4-L2*L2-u[2]*u[2]-v*v)/(2*L2);

	w[1]=u[1]*u[1]+v*v-a[1]*a[1];
	w[2]=u[2]*u[2]+v*v-a[2]*a[2];

	if (w[1]<0&&w[2]>0)
	{
		w[1]=0;
		Flag[1]=0;
		Flag[3]=0;
		Flag[5]=0;
		Flag[7]=0;
		m_explain1="w[1]���µĴ����";
		m_explain3="w[1]���µĴ����";
		m_explain5="w[1]���µĴ����";
		m_explain7="w[1]���µĴ����";
	//	UpdateData(false);
	}

	if (w[1]>0&&w[2]<0)//��ֹΪ�������Ĵ���
	{
		w[2]=0;
		Flag[2]=0;
		Flag[4]=0;
		Flag[6]=0;
		Flag[8]=0;
		m_explain2="w[2]���µĴ����";
		m_explain4="w[2]���µĴ����";
		m_explain6="w[2]���µĴ����";
		m_explain8="w[2]���µĴ����";
	//	UpdateData(false);

	}

	outo[1][2]=atan2(a[1]*v-u[1]*sqrt(w[1]),-1*a[1]*u[1]-v*sqrt(w[1]) );
	c2[1] =	 cos(outo[1][2]);
	s2[1] = sin(outo[1][2]);

//	if ( (-1*a[2]*u[2]-v*sqrt(u[2]*u[2]+v*v-a[2]*a[2]) )!=0 )
//	{
//	}

	outo[2][2]=atan2(a[2]*v-u[2]*sqrt(w[2]),-1*a[2]*u[2]-v*sqrt(w[2]));
	c2[2] =	 cos(outo[2][2]);
	s2[2] = sin(outo[2][2]);
	

	outo[3][2]=atan2(a[1]*v+u[1]*sqrt(w[1]),-1*a[1]*u[1]+v*sqrt(w[1]));
	c2[3] =	 cos(outo[3][2]);
	s2[3] = sin(outo[3][2]);
	
//	if ( (-1*a[2]*u[2]+v*sqrt(u[2]*u[2]+v*v-a[2]*a[2]) )!=0 )
//	{
//	}
	outo[4][2]=atan2(a[2]*v+u[2]*sqrt(w[2]),-1*a[2]*u[2]+v*sqrt(w[2]));
	c2[4] =	 cos(outo[4][2]);
	s2[4] = sin(outo[4][2]);

	outo[5][2]=outo[1][2];
	outo[6][2]=outo[2][2];
	outo[7][2]=outo[3][2];
	outo[8][2]=outo[4][2];
	

//��o3,��ȫȡ����o2�����������������
	outo[1][3]=atan2((s2[1]*u[1]+c2[1]*v)*L3 + (L2+s2[1]*v-c2[1]*u[1])*L4,(s2[1]*u[1]+c2[1]*v)*L4 - (L2+s2[1]*v-c2[1]*u[1])*L3);
	s3[1] = sin(outo[1][3]);
	c3[1] =	 cos(outo[1][3]);

	outo[2][3]=atan2((s2[2]*u[2]+c2[2]*v)*L3 + (L2+s2[2]*v-c2[2]*u[2])*L4,(s2[2]*u[2]+c2[2]*v)*L4 - (L2+s2[2]*v-c2[2]*u[2])*L3);
	s3[2] = sin(outo[2][3]);
	c3[2] =	 cos(outo[2][3]);

	outo[3][3]=atan2((s2[3]*u[1]+c2[3]*v)*L3 + (L2+s2[3]*v-c2[3]*u[1])*L4,(s2[3]*u[1]+c2[3]*v)*L4 - (L2+s2[3]*v-c2[3]*u[1])*L3);
	s3[3] = sin(outo[3][3]);
	c3[3] =	 cos(outo[3][3]);	

//	if ( ((s2[4]*u[2]+c2[4]*v)*L4 - (L2+s2[4]*v-c2[4]*u[2])*L3)!=0 )
//	{
//	}
		outo[4][3]=atan2((s2[4]*u[2]+c2[4]*v)*L3 + (L2+s2[4]*v-c2[4]*u[2])*L4,(s2[4]*u[2]+c2[4]*v)*L4 - (L2+s2[4]*v-c2[4]*u[2])*L3);
		s3[4] = sin(outo[4][3]);
		c3[4] =	 cos(outo[4][3]);
	
		outo[5][3]=outo[1][3];
		outo[6][3]=outo[2][3];
		outo[7][3]=outo[3][3];
		outo[8][3]=outo[4][3];



//��o5,�˸��⣬ȡ����o1o2o3.
	s23[1] = s2[1]*c3[1]-c2[1]*s3[1];
	s23[2] = s2[2]*c3[2]-c2[2]*s3[2];	
	s23[3] = s2[3]*c3[3]-c2[3]*s3[3];
	s23[4] = s2[4]*c3[4]-c2[4]*s3[4];

	c23[1] = c2[1]*c3[1]+s2[1]*s3[1];
	c23[2] = c2[2]*c3[2]+s2[2]*s3[2];
	c23[3] = c2[3]*c3[3]+s2[3]*s3[3];
	c23[4] = c2[4]*c3[4]+s2[4]*s3[4];


	h[1] = -1*s23[1]*(ax*c1[1]+ay*s1[1])-az*c23[1];
	h[2] = -1*s23[2]*(ax*c1[2]+ay*s1[2])-az*c23[2];
	h[3] = -1*s23[3]*(ax*c1[1]+ay*s1[1])-az*c23[3];
	h[4] = -1*s23[4]*(ax*c1[2]+ay*s1[2])-az*c23[4];


	outo[1][5] = atan2(sqrt(1-h[1]*h[1]),h[1]);
	s5[1] = sin(outo[1][5]);
	c5[1] =	 cos(outo[1][5]);

	outo[2][5] = atan2(sqrt(1-h[2]*h[2]),h[2]);
	s5[2] = sin(outo[2][5]);
	c5[2] =	 cos(outo[2][5]);

	outo[3][5] = atan2(sqrt(1-h[3]*h[3]),h[3]);
	s5[3] = sin(outo[3][5]);
	c5[3] =	 cos(outo[3][5]);

	outo[4][5] = atan2(sqrt(1-h[4]*h[4]),h[4]);
	s5[4] = sin(outo[4][5]);
	c5[4] =	 cos(outo[4][5]);

	outo[5][5] = atan2(-sqrt(1-h[1]*h[1]),h[1]);
	s5[5] = sin(outo[5][5]);
	c5[5] =	 cos(outo[5][5]);

	outo[6][5] = atan2(-sqrt(1-h[2]*h[2]),h[2]);
	s5[6] = sin(outo[6][5]);
	c5[6] =	 cos(outo[6][5]);

	outo[7][5] = atan2(-sqrt(1-h[3]*h[3]),h[3]);
	s5[7] = sin(outo[7][5]);
	c5[7] =	 cos(outo[7][5]);

	outo[8][5] = atan2(-sqrt(1-h[4]*h[4]),h[4]);
	s5[8] = sin(outo[8][5]);
	c5[8] =	 cos(outo[8][5]);

//��o4
//	if (((c23[1]*(ax*c1[1]+ay*s1[1])-az*s23[1])/s5[1])!=0&&s5[1]!=0)
//	{
//	}
	outo[1][4] = atan2(-(ax*s1[1]-ay*c1[1])/s5[1],(c23[1]*(ax*c1[1]+ay*s1[1])-az*s23[1])/s5[1]);
	s4[1] = sin(outo[1][4]);
	c4[1] =	 cos(outo[1][4]);

	outo[2][4] = atan2(-(ax*s1[2]-ay*c1[2])/s5[2],(c23[2]*(ax*c1[2]+ay*s1[2])-az*s23[2])/s5[2]);
	s4[2] = sin(outo[2][4]);
	c4[2] =	 cos(outo[2][4]);

	outo[3][4] = atan2(-(ax*s1[1]-ay*c1[1])/s5[3],(c23[3]*(ax*c1[1]+ay*s1[1])-az*s23[3])/s5[3]);
	s4[3] = sin(outo[3][4]);
	c4[3] =	 cos(outo[3][4]);

	outo[4][4] = atan2(-(ax*s1[2]-ay*c1[2])/s5[4],(c23[4]*(ax*c1[2]+ay*s1[2])-az*s23[4])/s5[4]);
	s4[4] = sin(outo[4][4]);
	c4[4] =	 cos(outo[4][4]);

//	if (((c23[1]*(ax*c1[1]+ay*s1[1])-az*s23[1])/s5[5])!=0&&s5[1]!=0)
//	{
//	}
	outo[5][4] = atan2(-(ax*s1[1]-ay*c1[1])/s5[5],(c23[1]*(ax*c1[1]+ay*s1[1])-az*s23[1])/s5[5]);
	s4[5] = sin(outo[5][4]);
	c4[5] =	 cos(outo[5][4]);

	outo[6][4] = atan2(-(ax*s1[2]-ay*c1[2])/s5[6],(c23[2]*(ax*c1[2]+ay*s1[2])-az*s23[2])/s5[6]);
	s4[6] = sin(outo[6][4]);
	c4[6] =	 cos(outo[6][4]);

	outo[7][4] = atan2(-(ax*s1[1]-ay*c1[1])/s5[7],(c23[3]*(ax*c1[1]+ay*s1[1])-az*s23[3])/s5[7]);
	s4[7] = sin(outo[7][4]);
	c4[7] =	 cos(outo[7][4]);

	outo[8][4] = atan2(-(ax*s1[2]-ay*c1[2])/s5[8],(c23[4]*(ax*c1[2]+ay*s1[2])-az*s23[4])/s5[8]);
	s4[8] = sin(outo[8][4]);
	c4[8] =	 cos(outo[8][4]);

//��o6
//	outo[1][6] = atan2(s4[1]*c5[1]*(c1[1]*oy-s1[1]*ox)-c4[1]*(s1[1]*nx-c1[1]*ny),(s1[1]*nx-c1[1]*ny)*(s1[1]*nx-c1[1]*ny)+(s1[1]*ox-c1[1]*oy)*(s1[1]*ox-c1[1]*oy));
	outo[1][6] = atan2(s4[1]*c5[1]*(c1[1]*oy-s1[1]*ox)-c4[1]*(s1[1]*nx-c1[1]*ny),s4[1]*c5[1]*(c1[1]*ny-s1[1]*nx)+c4[1]*(s1[1]*ox-c1[1]*oy));


	outo[2][6] = atan2(s4[2]*c5[2]*(c1[2]*oy-s1[2]*ox)-c4[2]*(s1[2]*nx-c1[2]*ny),s4[2]*c5[2]*(c1[2]*ny-s1[2]*nx)+c4[2]*(s1[2]*ox-c1[2]*oy));

	outo[3][6] = atan2(s4[3]*c5[3]*(c1[1]*oy-s1[1]*ox)-c4[3]*(s1[1]*nx-c1[1]*ny),s4[3]*c5[3]*(c1[1]*ny-s1[1]*nx)+c4[3]*(s1[1]*ox-c1[1]*oy));

	outo[4][6] = atan2(s4[4]*c5[4]*(c1[2]*oy-s1[2]*ox)-c4[4]*(s1[2]*nx-c1[2]*ny),s4[4]*c5[4]*(c1[2]*ny-s1[2]*nx)+c4[4]*(s1[2]*ox-c1[2]*oy));

	outo[5][6] = atan2(s4[5]*c5[5]*(c1[1]*oy-s1[1]*ox)-c4[5]*(s1[1]*nx-c1[1]*ny),s4[5]*c5[5]*(c1[1]*ny-s1[1]*nx)+c4[5]*(s1[1]*ox-c1[1]*oy));

	outo[6][6] = atan2(s4[6]*c5[6]*(c1[2]*oy-s1[2]*ox)-c4[6]*(s1[2]*nx-c1[2]*ny),s4[6]*c5[6]*(c1[2]*ny-s1[2]*nx)+c4[6]*(s1[2]*ox-c1[2]*oy));

	outo[7][6] = atan2(s4[7]*c5[7]*(c1[1]*oy-s1[1]*ox)-c4[7]*(s1[1]*nx-c1[1]*ny),s4[7]*c5[7]*(c1[1]*ny-s1[1]*nx)+c4[7]*(s1[1]*ox-c1[1]*oy));

	outo[8][6] = atan2(s4[8]*c5[8]*(c1[2]*oy-s1[2]*ox)-c4[8]*(s1[2]*nx-c1[2]*ny),s4[8]*c5[8]*(c1[2]*ny-s1[2]*nx)+c4[8]*(s1[2]*ox-c1[2]*oy));
}

void CZen_FanDlg::OnRunZhengJie() //�����������
{
	// TODO: Add your control notification handler code here
	UpdateData(true);
	ino[1]=m_ino1*PI/180;
	ino[2]=m_ino2*PI/180;
	ino[3]=m_ino3*PI/180;
	ino[4]=m_ino4*PI/180;

	if (m_ino5==0)
	{m_ino5=0.0001;
	}
	ino[5]=m_ino5*PI/180;
	ino[6]=m_ino6*PI/180;

	CS_Left[0]=m_ino1;
	CS_Left[1]=m_ino2+90;
	CS_Left[2]=m_ino3;
	CS_Left[3]=m_ino4;
	CS_Left[4]=m_ino5+90;
	CS_Left[5]=m_ino6;

	m_pDisplay->OnPaint2();
	RunZheng();
	
	m_nx=nx;
	m_ny=ny;
	m_nz=nz;

	m_ox=ox;
	m_oy=oy;
	m_oz=oz;

	m_ax=ax;
	m_ay=ay;
	m_az=az;

	m_px=px;
	m_py=py;
	m_pz=pz;

	UpdateData(false);

}

void CZen_FanDlg::OnRunNi() 
{
	// TODO: Add your control notification handler code here

	UpdateData(true);
	nx=m_nx;
	ny=m_ny;
	nz=m_nz;
	
	ox=m_ox;
	oy=m_oy;
	oz=m_oz;
	
	ax=m_ax;
	ay=m_ay;
	az=m_az;
	
	px=m_px;
	py=m_py;
	pz=m_pz;

	m_explain1="";
	m_explain2="";
	m_explain3="";
	m_explain4="";
	m_explain5="";
	m_explain6="";
	m_explain7="";
	m_explain8="";
	RunNijie();

	m_OutO11=outo[1][1]*180/PI;
	m_OutO12=outo[1][2]*180/PI;
	m_OutO13=outo[1][3]*180/PI;
	m_OutO14=outo[1][4]*180/PI;
	m_OutO15=outo[1][5]*180/PI;
	m_OutO16=outo[1][6]*180/PI;

	m_OutO21=outo[2][1]*180/PI;
	m_OutO22=outo[2][2]*180/PI;
	m_OutO23=outo[2][3]*180/PI;
	m_OutO24=outo[2][4]*180/PI;
	m_OutO25=outo[2][5]*180/PI;
	m_OutO26=outo[2][6]*180/PI;

	m_OutO31=outo[1][1]*180/PI;
	m_OutO32=outo[3][2]*180/PI;
	m_OutO33=outo[3][3]*180/PI;
	m_OutO34=outo[3][4]*180/PI;
	m_OutO35=outo[3][5]*180/PI;
	m_OutO36=outo[3][6]*180/PI;

	m_OutO41=outo[2][1]*180/PI;
	m_OutO42=outo[4][2]*180/PI;
	m_OutO43=outo[4][3]*180/PI;
	m_OutO44=outo[4][4]*180/PI;
	m_OutO45=outo[4][5]*180/PI;
	m_OutO46=outo[4][6]*180/PI;

	m_OutO51=outo[1][1]*180/PI;
	m_OutO52=outo[1][2]*180/PI;
	m_OutO53=outo[1][3]*180/PI;
	m_OutO54=outo[5][4]*180/PI;
	m_OutO55=outo[5][5]*180/PI;
	m_OutO56=outo[5][6]*180/PI;

	m_OutO61=outo[2][1]*180/PI;
	m_OutO62=outo[2][2]*180/PI;
	m_OutO63=outo[2][3]*180/PI;
	m_OutO64=outo[6][4]*180/PI;
	m_OutO65=outo[6][5]*180/PI;
	m_OutO66=outo[6][6]*180/PI;

	m_OutO71=outo[1][1]*180/PI;
	m_OutO72=outo[3][2]*180/PI;
	m_OutO73=outo[3][3]*180/PI;
	m_OutO74=outo[7][4]*180/PI;	
	m_OutO75=outo[7][5]*180/PI;
	m_OutO76=outo[7][6]*180/PI;

	m_OutO81=outo[2][1]*180/PI;
	m_OutO82=outo[4][2]*180/PI;
	m_OutO83=outo[4][3]*180/PI;
	m_OutO84=outo[8][4]*180/PI;	
	m_OutO85=outo[8][5]*180/PI;
	m_OutO86=outo[8][6]*180/PI;

	m_explain1+=DetAngScal(m_OutO11,m_OutO12,m_OutO13,m_OutO14,m_OutO15);
	m_explain2+=DetAngScal(m_OutO21,m_OutO22,m_OutO23,m_OutO24,m_OutO25);
	m_explain3+=DetAngScal(m_OutO31,m_OutO32,m_OutO33,m_OutO34,m_OutO35);
	m_explain4+=DetAngScal(m_OutO41,m_OutO42,m_OutO43,m_OutO44,m_OutO45);
	m_explain5+=DetAngScal(m_OutO51,m_OutO52,m_OutO53,m_OutO54,m_OutO55);
	m_explain6+=DetAngScal(m_OutO61,m_OutO62,m_OutO63,m_OutO64,m_OutO65);
	m_explain7+=DetAngScal(m_OutO71,m_OutO72,m_OutO73,m_OutO74,m_OutO75);
	m_explain8+=DetAngScal(m_OutO81,m_OutO82,m_OutO83,m_OutO84,m_OutO85);

	UpdateData(false);
}

CZen_FanDlg::~CZen_FanDlg()
{
	if (m_pDisplay)
	{
		delete m_pDisplay;
	}
}

void CZen_FanDlg::OnDisAns1() 
{
	// TODO: Add your control notification handler code here
	CS_Left[0]=m_OutO11;
	CS_Left[1]=m_OutO12+90;
	CS_Left[2]=m_OutO13;
	CS_Left[3]=m_OutO14;
	CS_Left[4]=m_OutO15+90;
	CS_Left[5]=m_OutO16;
	m_pDisplay->OnPaint2();
}

void CZen_FanDlg::OnDisAns2() 
{
	// TODO: Add your control notification handler code here
	CS_Left[0]=m_OutO21;
	CS_Left[1]=m_OutO22+90;
	CS_Left[2]=m_OutO23;
	CS_Left[3]=m_OutO24;
	CS_Left[4]=m_OutO25+90;
	CS_Left[5]=m_OutO26;
	m_pDisplay->OnPaint2();
}

void CZen_FanDlg::OnDisAns3() 
{
	// TODO: Add your control notification handler code here
	CS_Left[0]=m_OutO31;
	CS_Left[1]=m_OutO32+90;
	CS_Left[2]=m_OutO33;
	CS_Left[3]=m_OutO34;
	CS_Left[4]=m_OutO35+90;
	CS_Left[5]=m_OutO36;
	m_pDisplay->OnPaint2();
}

void CZen_FanDlg::OnDisAns4() 
{
	// TODO: Add your control notification handler code here
	CS_Left[0]=m_OutO41;
	CS_Left[1]=m_OutO42+90;
	CS_Left[2]=m_OutO43;
	CS_Left[3]=m_OutO44;
	CS_Left[4]=m_OutO45+90;
	CS_Left[5]=m_OutO46;
	m_pDisplay->OnPaint2();
}

void CZen_FanDlg::OnDisAns5() 
{
	// TODO: Add your control notification handler code here
	CS_Left[0]=m_OutO51;
	CS_Left[1]=m_OutO52+90;
	CS_Left[2]=m_OutO53;
	CS_Left[3]=m_OutO54;
	CS_Left[4]=m_OutO55+90;
	CS_Left[5]=m_OutO56;
	m_pDisplay->OnPaint2();
}

void CZen_FanDlg::OnDisAns6() 
{
	// TODO: Add your control notification handler code here
	CS_Left[0]=m_OutO61;
	CS_Left[1]=m_OutO62+90;
	CS_Left[2]=m_OutO63;
	CS_Left[3]=m_OutO64;
	CS_Left[4]=m_OutO65+90;
	CS_Left[5]=m_OutO66;
	m_pDisplay->OnPaint2();
}

void CZen_FanDlg::OnDisAns7() 
{
	// TODO: Add your control notification handler code here
	CS_Left[0]=m_OutO71;
	CS_Left[1]=m_OutO72+90;
	CS_Left[2]=m_OutO73;
	CS_Left[3]=m_OutO74;
	CS_Left[4]=m_OutO75+90;
	CS_Left[5]=m_OutO76;
	m_pDisplay->OnPaint2();
}

void CZen_FanDlg::OnDisAns8() 
{
	// TODO: Add your control notification handler code here
	CS_Left[0]=m_OutO81;
	CS_Left[1]=m_OutO82+90;
	CS_Left[2]=m_OutO83;
	CS_Left[3]=m_OutO84;
	CS_Left[4]=m_OutO85+90;
	CS_Left[5]=m_OutO86;
	m_pDisplay->OnPaint2();
}







CString CZen_FanDlg::DetAngScal(double aa, double bb, double cc, double dd, double ee)
{	int i=0;
	CString str=" ";

	if (aa<-170||aa>170)
	{i=1;
	str+="��1";
	}

	if (bb<-180||bb>65)
	{i=1;
	str+="��2";
	}

	if (cc<-83||cc>180)
	{i=1;
	str+="��3";
	}
	
	if (dd<-180||dd>180)
	{i=1;
	str+="��4";
	}

	if (ee<-135||ee>135)
	{i=1;
	str+="��5";
	}
	
	if (i)
	{str+="������Ƕȷ�Χ";
	}

	return str;
}

void CZen_FanDlg::OnCalLinePos() 
{
	// TODO: Add your control notification handler code here
	double zo,yo,czo,szo,cyo,syo;
	UpdateData(true);
	px=m_px;
	py=m_py;
	pz=m_pz;

	zo=atan2(py,px);
	szo=sin(zo);
	czo=cos(zo);

	yo=atan2(sqrt(px*px+py*py),pz);
	syo=sin(yo);
	cyo=cos(yo);

	nx=cyo*czo;
	ny=szo*cyo;
	nz=-syo;
	ox=-szo;
	oy=czo;
	oz=0;
	ax=syo*czo;
	ay=szo*syo;
	az=cyo;

	m_nx=nx;
	m_ny=ny;
	m_nz=nz;
	
	m_ox=ox;
	m_oy=oy;
	m_oz=oz;
	
	m_ax=ax;
	m_ay=ay;
	m_az=az;
	UpdateData(false);

}

void CZen_FanDlg::OnCalLinePosNei() 
{
	// TODO: Add your control notification handler code here
	double zo,yo,czo,szo,cyo,syo;
	UpdateData(true);
	px=-m_px;
	py=-m_py;
	pz=-m_pz;
	
	zo=atan2(py,px);
	szo=sin(zo);
	czo=cos(zo);
	
	yo=atan2(sqrt(px*px+py*py),pz);
	syo=sin(yo);
	cyo=cos(yo);
	
	nx=cyo*czo;
	ny=szo*cyo;
	nz=-syo;
	ox=-szo;
	oy=czo;
	oz=0;
	ax=syo*czo;
	ay=szo*syo;
	az=cyo;
	
	m_nx=nx;
	m_ny=ny;
	m_nz=nz;
	
	m_ox=ox;
	m_oy=oy;
	m_oz=oz;
	
	m_ax=ax;
	m_ay=ay;
	m_az=az;
	UpdateData(false);
}



void CZen_FanDlg::OnDisScaleOut() 
{
	double s_o,s_q,s_r;//s_oΪ��z��ļнǣ�s_qΪ��x��ļн�,s_r��ʾ����
	double wpx,wpy,wpz;//���λ��
	double wnx,wny,wnz,wox,woy,woz,wax,way,waz;//��̬
	double czo,szo,cyo,syo;
	int f;
	double dpox=0,dpoy=0,dpoz=0,r;
	ofstream outfile;
	outfile.open("DSInn.txt",ios::out);
	outfile.close();
	outfile.open("DSInn.txt",ios::out|ios::app);

	pointnum=0;

	for (s_q=0;s_q<=PI*2;s_q+=PI/18)
	{
		for (s_o=0;s_o<=PI;s_o+=PI/18)
		{
		//	for (s_r=2000;s_r>300;s_r-=100)//�����ڵ�
			for (s_r=500;s_r<1500;s_r+=10)//�������
			{
				//����̬
				for (int k=1;k<9;k++)//�жϽ��Ƿ���ȷ���������
				{
					Flag[k]=1;
				}
				
		
				wpx=s_r*sin(s_o)*cos(s_q);
				wpy=s_r*sin(s_o)*sin(s_q);
				wpz=s_r*cos(s_o);
				
				//�������
				czo=cos(s_q);
				szo=sin(s_q);
				cyo=cos(s_o);
				syo=sin(s_o);
		/*	
				//�����ڵ�
				czo=cos(PI+s_q);
				szo=sin(PI+s_q);
				cyo=cos(PI-s_o);
				syo=sin(PI-s_o);
		*/

				wnx=cyo*czo;
				wny=szo*cyo;
				wnz=-syo;
				wox=-szo;
				woy=czo;
				woz=0;
				wax=syo*czo;
				way=szo*syo;
				waz=cyo;
	
				f=JudgeAnswer(wnx,wny,wnz,wox,woy,woz,wax,way,waz,wpx,wpy,wpz);//�ж��Ƿ��п�ʵ�ֵĽ�

				if (f)
				{
					dpox=wpx;
					dpoy=wpy;
					dpoz=wpz;
					r=s_r;
					for (int p=1;p<9;p++)
					{
						flagg[p]=Flag[p];
					}
				}

		}
			
			if ((dpox!=0)||(dpoy!=0)||(dpoz!=0))
			{	
				if (1==flagg[1])
				{
					ranum[1]++;
				}
				else
				{
					for (int n=2;n<9;n++)
					{
						if (1==flagg[n])
						{
							ranum[n]++;
						}
					}
				}
				outfile<<dpox<<" "<<dpoy<<" "<<dpoz+550<<endl;
				TRACE("num=%d,s_r=%lf,dpox=%lf,dpoy=%lf,dpoz=%lf",pointnum,r,dpox,dpoy,dpoz);
				pointnum++;
				dpox=0;dpoy=0;dpoz=0;
			}
		}
	}
	outfile.close();
	m_pDisplay->OnPaint2();
	for (int m=1;m<9;m++)
	{
		TRACE("%d",ranum[m]);
	}


	
}



int CZen_FanDlg::JudgeAnswer(double vnx, double vny, double vnz, double vox, double voy, double voz, double vax, double vay, double vaz, double vpx, double vpy, double vpz)
{
	int i,s=0;
	CString str=" ";

	nx=vnx;
	ny=vny;
	nz=vnz;

	ox=vox;
	oy=voy;
	oz=voz;

	ax=vax;
	ay=vay;
	az=vaz;

	px=vpx;
	py=vpy;
	pz=vpz;
	
	RunNijie();

	for (i=1;i<9;i++)
	{
		str=DetAngScal(outo[i][1]*180/PI,outo[i][2]*180/PI,outo[i][3]*180/PI,outo[i][4]*180/PI,outo[i][5]*180/PI);
		if (str!=" ")
		{
			Flag[i]=0;
		}
/*		if (1==i&&1==Flag[1])
		{
			ranum[1]++;
		}
		if (i>1&&1!=Flag[1]&&1==Flag[i])
		{
			ranum[i]++;
		}*/

		s=s+Flag[i];
	}
	

	if (0==s) return 0;
	else return 1;
	

}



void CZen_FanDlg::OnDrawOut() 
{
	if (0==DrawFlag[0])
	{
		DrawFlag[0]=1;
	}
	else DrawFlag[0]=0;
	m_pDisplay->OnPaint2();
}

void CZen_FanDlg::OnDrawIn() 
{
	if (0==DrawFlag[1])
	{
		DrawFlag[1]=1;
	}
	else DrawFlag[1]=0;
	m_pDisplay->OnPaint2();
}
