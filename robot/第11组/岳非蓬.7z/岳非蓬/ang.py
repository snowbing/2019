# -*- coding:utf-8 -*- 
import math
import matplotlib.pyplot as plt 
from imutils.perspective import four_point_transform 
from imutils import contours 
import numpy as np 
import imutils 
import cv2 as cv
import cv2

def ang():
    cap=cv.VideoCapture(1)
    cap.set(3,320)
    cap.set(4,240)
    ret, img = cap.read()
    img = cv.flip(img, -1)
    ang=0

    # 打印原图 
    cv.imshow("video", img) 
    k = cv.waitKey(5000)
    # 灰度化 
    gray=cv.cvtColor(img,cv.COLOR_BGR2GRAY) 

    # 打印灰度图 
    cv.imshow("gray",gray) 
    cv.waitKey(1)
    # 高斯滤波，清除一些杂点 
    blur=cv.GaussianBlur(gray,(3,3),0) 

    # 自适应二值化算法 
    thresh2 = cv.adaptiveThreshold(blur,255,cv.ADAPTIVE_THRESH_GAUSSIAN_C, cv.THRESH_BINARY_INV,131,4) 

 
    # 打印二值化后的图 
    cv.imshow("thresh2",thresh2) 
    k = cv.waitKey(5000)

    # 寻找轮廓 
    #image, cts, hierarchy = cv.findContours(thresh2, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE) 
    cts, hierarchy = cv.findContours(thresh2, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE) 

 
    # 打印找到的轮廓 
    print("轮廓数：",len(cts)) 

    # 对拷贝的原图进行轮廓标记 
    contour_flagged=cv.drawContours(img.copy(), cts, -1, (0, 0, 255), 3) 
    # 打印轮廓图 
    cv.imshow("contours_flagged", contour_flagged) 
    # 按像素面积降序排序 
    list = sorted(cts, key=cv.contourArea, reverse=True) 

 
    # 遍历轮廓 
    for ct in list: 
        # 周长，第1个参数是轮廓，第二个参数代表是否是闭环的图形 
        peri = 0.01 * cv.arcLength(ct, True) 
        # 获取多边形的所有定点，如果是四个定点，就代表是矩形 
        approx = cv.approxPolyDP(ct, peri, True) 
        # 只考虑矩形 
        if len(approx) == 4: 
            print("hello")
            leftUp,leftDown,rightDown,rightUp=approx
            cX=(leftUp[0][0]+leftDown[0][0]+rightUp[0][0]+rightDown[0][0])/4
            cY=(leftUp[0][1]+leftDown[0][1]+rightUp[0][1]+rightDown[0][1])/4
            ang=(math.degrees(math.atan((240-cY)/(cX-160))))/180
            print (ang)
    return (ang)

