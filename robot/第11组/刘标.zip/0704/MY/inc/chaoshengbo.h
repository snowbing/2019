#ifndef __CHAOSHENGBO_H
#define __CHAOSHENGBO_H

#include "stm32f10x.h"

void cinit(void);
void TIM6_Int_Init(void);
void TIMEOPEN(void);
void TIMECLOSE(void);
u32 GetEchoTimer(void);
float alls(void);

#endif 
