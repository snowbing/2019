/*-------------------------------------------------------------------------------
�ļ����ƣ�main.c
�ļ���������������LED��˸��S1ȡ��LED2��S2ȡ��LED3��S3ͬʱȡ��LED2��LED3
          S4ʹLED2��LED3��˸5��
Ӳ��ƽ̨����ĪM3S������
��д������shifang
�̼���  ��V3.5
������̳��www.doflye.net
��    ע��ͨ�����޸Ŀ�����ֲ�����������壬����������Դ�����硣
---------------------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "duoji.h"

void duojiInit(void)
{
	
	
	/*------M05*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure3;
  GPIO_InitStructure3.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7;
  GPIO_InitStructure3.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure3.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure3);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure3;
	TIM_OCInitTypeDef TIM_OCInitStructure3;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	TIM_TimeBaseStructure3.TIM_Period=1999;
	TIM_TimeBaseStructure3.TIM_Prescaler=719;
	TIM_TimeBaseStructure3.TIM_ClockDivision=0;
	TIM_TimeBaseStructure3.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseStructure3);
	
	TIM_OCInitStructure3.TIM_OCMode=TIM_OCMode_PWM2;
	TIM_OCInitStructure3.TIM_Pulse=0;
	TIM_OCInitStructure3.TIM_OutputState=TIM_OutputState_Enable;
	TIM_OCInitStructure3.TIM_OCPolarity=TIM_OCPolarity_Low;
	TIM_OC1Init(TIM3,&TIM_OCInitStructure3);
	
	TIM_OCInitStructure3.TIM_OCMode=TIM_OCMode_PWM2;
	TIM_OCInitStructure3.TIM_Pulse=0;
	TIM_OCInitStructure3.TIM_OutputState=TIM_OutputState_Enable;
	TIM_OCInitStructure3.TIM_OCPolarity=TIM_OCPolarity_Low;
	TIM_OC2Init(TIM3,&TIM_OCInitStructure3);
	
	TIM_Cmd(TIM3,ENABLE);
	
	/*------M04*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure1;
  GPIO_InitStructure1.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8;
  GPIO_InitStructure1.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure1.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure1);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure1;
	TIM_OCInitTypeDef TIM_OCInitStructure1;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	TIM_TimeBaseStructure1.TIM_Period=199;
	TIM_TimeBaseStructure1.TIM_Prescaler=7199;
	TIM_TimeBaseStructure1.TIM_ClockDivision=0;
	TIM_TimeBaseStructure1.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM4,&TIM_TimeBaseStructure1);
	
	TIM_OCInitStructure1.TIM_OCMode=TIM_OCMode_PWM2;
	TIM_OCInitStructure1.TIM_Pulse=9;
	TIM_OCInitStructure1.TIM_OutputState=TIM_OutputState_Enable;
	TIM_OCInitStructure1.TIM_OCPolarity=TIM_OCPolarity_Low;
	TIM_OC1Init(TIM4,&TIM_OCInitStructure1);
	
	TIM_OCInitStructure1.TIM_OCMode=TIM_OCMode_PWM2;
	TIM_OCInitStructure1.TIM_Pulse=12;
	TIM_OCInitStructure1.TIM_OutputState=TIM_OutputState_Enable;
	TIM_OCInitStructure1.TIM_OCPolarity=TIM_OCPolarity_Low;
	TIM_OC2Init(TIM4,&TIM_OCInitStructure1);
	
	TIM_OCInitStructure1.TIM_OCMode=TIM_OCMode_PWM2;
	TIM_OCInitStructure1.TIM_Pulse=15;
	TIM_OCInitStructure1.TIM_OutputState=TIM_OutputState_Enable;
	TIM_OCInitStructure1.TIM_OCPolarity=TIM_OCPolarity_Low;
	TIM_OC3Init(TIM4,&TIM_OCInitStructure1);
	
	
	
	TIM_Cmd(TIM4,ENABLE);
	
	

/*----------------------�·��� ������̳��www.doflye.net--------------------------*/
}
