/*-------------------------------------------------------------------------------
�ļ����ƣ�main.c
�ļ���������������LED��˸��S1ȡ��LED2��S2ȡ��LED3��S3ͬʱȡ��LED2��LED3
          S4ʹLED2��LED3��˸5��
Ӳ��ƽ̨����ĪM3S������
��д������shifang
�̼���  ��V3.5
������̳��www.doflye.net
��    ע��ͨ�����޸Ŀ�����ֲ�����������壬����������Դ�����硣
---------------------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "led.h"
#include "delay.h"
#include "key.h"
#include "usart1.h"
#include "chaoshengbo.h"
#include "duoji.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "misc.h"

extern char USART2_RX_BUF[USART2_REC_LEN];
extern int n1,s1;extern int n2,s2;
extern int n3,s3;extern int n4,s4;
extern int n5,s5;extern int s6;
extern int s7,s9;extern int n10,s10;
extern int n11,s11;

void M05xiaL(int N1)
{
				N1=54*N1;
				TIM_SetCompare1(TIM3,140);
				Delay_ms(N1);
				TIM_SetCompare1(TIM3,0);
}

void M05xiaR(int N10)
{
				N10=51*N10;
				TIM_SetCompare1(TIM3,150);
				Delay_ms(N10);
				TIM_SetCompare1(TIM3,0);
}

void M05shangL(int N2)
{
				N2=52*N2;
				TIM_SetCompare2(TIM3,138);
				Delay_ms(N2);
				TIM_SetCompare2(TIM3,0);
}

void M05shangR(int N11)
{
				N11=30*N11;
				TIM_SetCompare2(TIM3,150);
				Delay_ms(N11);
				TIM_SetCompare2(TIM3,0);
}
int main()
{
	cinit();
	TIM6_Int_Init();
	SysTick_Init();
	LED_Init();
	uart2_init(115200);
	duojiInit();
	
	float length;
	char a[10];
	s1=s2=s3=s4=s5=s6=s7=s9=s10=s11=0;
	while(1)
	{
			
		if(s1==1)		//M05xiaL
			{
				M05xiaL(n1);
				s1=0;
			}
			if(s10==1)		//M05xiaR
			{
				M05xiaR(n10);
				s10=0;
			}
			if(s2==1)		//M05shangL
			{
				M05shangL(n2);
				s2=0;
			}
			if(s11==1)		//M05shangR
			{
				M05shangR(n11);
				s11=0;
			}
			if(s3==1)		//M0401
			{
				TIM_SetCompare1(TIM4,n3);
				s3=0;
			}
			if(s4==1)		//M0402
			{
				TIM_SetCompare2(TIM4,n4);
				s4=0;
			}
			if(s5==1)		//M0403
			{
				TIM_SetCompare3(TIM4,n5);
				s5=0;
			}
			if(s6==1)		//chaoshengbo
			{
				length=alls();
				sprintf(a,"%f",length);
				RS232_2_Send_Data((u8*)a,7);
				RS232_2_Send_Data((u8*)"\n",1);
				s6=0;
			}	
			if(s7==1)		//RESET
			{
				duojiInit();
				s7=0;
			}
			if(s9==1)
			{
				M05xiaR(90);
				Delay_ms(500);
				TIM_SetCompare1(TIM4,13);
				Delay_ms(1000);
				TIM_SetCompare2(TIM4,5);
				Delay_ms(1000);
				TIM_SetCompare3(TIM4,8);
				Delay_ms(1000);
				duojiInit();
				s9=0;
			}
			Delay_us(100);
	};
	
}

/*----------------------�·��� ������̳��www.doflye.net--------------------------*/
