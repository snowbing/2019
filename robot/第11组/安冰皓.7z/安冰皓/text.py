#coding=utf-8
import sys
reload(sys)
sys.setdefaultencoding('utf8')
import getaudio


def begin():
    a = '开始'
    b = (getaudio.get())
    print (b)
    if a == b :
        return True
    else: 
        return False


def end():
    a = '结束'
    b = (getaudio.get())
    print (b)
    if a== b :
        return True
    else: 
        return False

