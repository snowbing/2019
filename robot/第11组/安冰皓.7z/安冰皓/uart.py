import serial
import time


ser = serial.Serial("/dev/ttyAMA0", 9600)


def send(data):
    print('do it');
    while True:
        ser.write(data)
        time.sleep(0.1)
        break

