import text
import mes
import move
import time


while True : 
    begin = text.begin()
    end = text.end()
    if begin == True:
        mes.mes()
        time.sleep(1.0)
        move.move()
    if end == True :
        break