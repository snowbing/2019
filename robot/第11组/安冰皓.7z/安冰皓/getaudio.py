#coding=utf-8
import wave
from aip import AipSpeech
import subprocess
import pyaudio
import os


APP_ID = "16654079"
API_Key = "eHFVqVZBur5Wx9f21PDGXohL"
SECRET_KEY = "xUrKbSnZ1yum1qwbNsWL69cOcS17PMkG"
client = AipSpeech(APP_ID, API_Key, SECRET_KEY)
CHUNK = 1024
FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 16000
RECORD_SECONDS = 3

def rec(file_name):
    p = pyaudio.PyAudio()

    stream = p.open(format=FORMAT,
                    channels=CHANNELS,
                    rate=RATE,
                    input=True,
                    frames_per_buffer=CHUNK)

    print("开始录音,请说话......")

    frames = []

    for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
        data = stream.read(CHUNK)
        frames.append(data)

    stream.stop_stream()
    stream.close()
    p.terminate()

    wf = wave.open(file_name, 'wb')
    wf.setnchannels(CHANNELS)
    wf.setsampwidth(p.get_sample_size(FORMAT))
    wf.setframerate(RATE)
    wf.writeframes(b''.join(frames))
    wf.close()
def wav_to_pcm(wav_file):
    pcm_file = "./%s.pcm" %(wav_file.split(".")[0])
    cmd = 'ffmpeg -y  -i %s  -acodec pcm_s16le -f s16le -ac 1 -ar 16000 %s'%(wav_file,pcm_file)
    p = subprocess.Popen(cmd, shell = True)
    p.wait()

    return pcm_file

def get_file_content(filePath):
    with open(filePath, 'rb') as fp:
        return fp.read()


def get():
    rec("speech.wav")
    pcm_file= wav_to_pcm("speech.wav")
    with open(pcm_file,"rb")as fp:
        file_context = fp.read()
    result = client.asr(file_context,'pcm',16000,{'dev_pid':1536,})
    if 'result' in result:
        result= result['result'][0]
    return result
